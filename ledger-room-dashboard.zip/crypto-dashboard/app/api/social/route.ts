import { NextRequest, NextResponse } from "next/server";
import { getSocialData } from "@/lib/services/social";
import type { ChainId } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as { chain: ChainId; address: string; coingeckoId?: string | null };
    const social = await getSocialData(body.chain, body.address, body.coingeckoId ?? null);
    return NextResponse.json({ social });
  } catch (err) {
    console.error("[api/social] erreur:", err);
    return NextResponse.json({ error: "Donnees sociales indisponibles pour le moment." }, { status: 500 });
  }
}
