import { NextRequest, NextResponse } from "next/server";
import { buildPortfolio } from "@/lib/portfolio";
import type { WalletAddresses } from "@/lib/types";

export const dynamic = "force-dynamic";

function isSafeSolanaAddress(addr: string): boolean {
  return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(addr);
}
function isSafeEvmAddress(addr: string): boolean {
  return /^0x[a-fA-F0-9]{40}$/.test(addr);
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      addresses: WalletAddresses;
      costBasis?: Record<string, number>;
    };

    const solana = (body.addresses?.solana || []).filter(isSafeSolanaAddress).slice(0, 10);
    const base = (body.addresses?.base || []).filter(isSafeEvmAddress).slice(0, 10);

    if (solana.length === 0 && base.length === 0) {
      return NextResponse.json({ error: "Aucune adresse valide fournie." }, { status: 400 });
    }

    const positions = await buildPortfolio({ solana, base }, body.costBasis || {});
    return NextResponse.json({ positions, fetchedAt: Date.now() });
  } catch (err) {
    console.error("[api/portfolio] erreur:", err);
    return NextResponse.json(
      { error: "Impossible de recuperer le portefeuille pour le moment. Reessayez dans quelques instants." },
      { status: 500 }
    );
  }
}
