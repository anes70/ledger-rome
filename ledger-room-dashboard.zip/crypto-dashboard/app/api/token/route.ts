import { NextRequest, NextResponse } from "next/server";
import { getMarketChart } from "@/lib/services/coingecko";
import { computeIndicators } from "@/lib/indicators";
import { generateAdvice } from "@/lib/aiEngine";
import type { ChainId } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      coingeckoId: string | null;
      chain: ChainId;
      priceUsd: number | null;
      priceChange24h: number | null;
      priceChange7d: number | null;
      liquidityUsd: number | null;
      volume24hUsd: number | null;
      marketCapUsd: number | null;
      ageInDays: number | null;
      avgBuyPrice: number | null;
      pnlPct: number | null;
    };

    const priceHistory7d = body.coingeckoId ? await getMarketChart(body.coingeckoId, 7) : [];
    const indicators = priceHistory7d.length > 0 ? computeIndicators(priceHistory7d) : null;

    const advice = generateAdvice({
      priceUsd: body.priceUsd,
      priceChange24h: body.priceChange24h,
      priceChange7d: body.priceChange7d,
      liquidityUsd: body.liquidityUsd,
      volume24hUsd: body.volume24hUsd,
      marketCapUsd: body.marketCapUsd,
      ageInDays: body.ageInDays,
      avgBuyPrice: body.avgBuyPrice,
      pnlPct: body.pnlPct,
      indicators,
      priceHistory7d
    });

    return NextResponse.json({ priceHistory7d, indicators, advice });
  } catch (err) {
    console.error("[api/token] erreur:", err);
    return NextResponse.json({ error: "Analyse indisponible pour le moment." }, { status: 500 });
  }
}
