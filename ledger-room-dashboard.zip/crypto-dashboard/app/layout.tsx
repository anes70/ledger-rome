import type { Metadata } from "next";
import { Inter, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const body = Inter({ subsets: ["latin"], variable: "--font-body", display: "swap" });
const display = Space_Grotesk({ subsets: ["latin"], variable: "--font-display", display: "swap" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono", display: "swap" });

export const metadata: Metadata = {
  title: "Ledger Room — Dashboard Crypto",
  description: "Suivi automatique de portefeuille Base & Solana : PNL, analyse technique, on-chain, social et IA."
};

// Inline script executed before hydration to avoid a flash of the wrong theme.
const themeBootstrap = `
(function() {
  try {
    var stored = localStorage.getItem('ledgerroom-theme');
    var theme = stored ? JSON.parse(stored) : null;
    var mode = theme && theme.state && theme.state.mode ? theme.state.mode : 'dark';
    document.documentElement.classList.remove('light', 'dark');
    document.documentElement.classList.add(mode);
  } catch (e) {
    document.documentElement.classList.add('dark');
  }
})();
`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className="dark" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeBootstrap }} />
      </head>
      <body className={`${body.variable} ${display.variable} ${mono.variable}`}>
        {children}
      </body>
    </html>
  );
}
