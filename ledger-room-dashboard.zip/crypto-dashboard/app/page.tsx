"use client";

import { useEffect, useState } from "react";
import { AlertTriangle } from "lucide-react";
import { Header } from "@/components/Header";
import { WalletInput } from "@/components/WalletInput";
import { PortfolioSummaryCards } from "@/components/PortfolioSummaryCards";
import { AllocationChart } from "@/components/AllocationChart";
import { PnlChart } from "@/components/PnlChart";
import { TokenTable } from "@/components/TokenTable";
import { TokenDetailDrawer } from "@/components/TokenDetailDrawer";
import { AlertsPanel } from "@/components/AlertsPanel";
import { HistoryPanel } from "@/components/HistoryPanel";
import { usePortfolioStore } from "@/store/usePortfolioStore";
import type { TokenPosition, AlertRule } from "@/lib/types";

const AUTO_REFRESH_MS = 60_000;

export default function DashboardPage() {
  const addresses = usePortfolioStore((s) => s.addresses);
  const tokens = usePortfolioStore((s) => s.tokens);
  const error = usePortfolioStore((s) => s.error);
  const refresh = usePortfolioStore((s) => s.refresh);
  const checkAlerts = usePortfolioStore((s) => s.checkAlerts);

  const [selectedToken, setSelectedToken] = useState<TokenPosition | null>(null);
  const [triggered, setTriggered] = useState<AlertRule[]>([]);
  const hasAddresses = addresses.solana.length + addresses.base.length > 0;

  useEffect(() => {
    if (!hasAddresses) return;
    refresh();
    const interval = setInterval(refresh, AUTO_REFRESH_MS);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasAddresses]);

  useEffect(() => {
    const hits = checkAlerts();
    if (hits.length > 0) setTriggered((prev) => [...hits, ...prev].slice(0, 5));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tokens]);

  // Garde le token selectionne synchronise avec les donnees fraiches apres actualisation.
  useEffect(() => {
    if (!selectedToken) return;
    const fresh = tokens.find((t) => t.chain === selectedToken.chain && t.address === selectedToken.address);
    if (fresh) setSelectedToken(fresh);
  }, [tokens, selectedToken]);

  return (
    <div className="min-h-screen">
      <Header />

      {triggered.length > 0 && (
        <div className="mx-auto max-w-[1400px] px-6 pt-4">
          {triggered.map((a) => (
            <div key={a.id} className="mb-2 flex items-center gap-2 rounded-lg border border-signal-amber/30 bg-signal-amberDim px-4 py-2 text-xs text-signal-amber">
              <AlertTriangle size={14} />
              Alerte declenchee sur {a.tokenAddress.slice(0, 6)}… — seuil {a.threshold} atteint.
              <button className="ml-auto underline" onClick={() => setTriggered((prev) => prev.filter((t) => t.id !== a.id))}>
                Fermer
              </button>
            </div>
          ))}
        </div>
      )}

      {error && (
        <div className="mx-auto max-w-[1400px] px-6 pt-4">
          <div className="rounded-lg border border-signal-down/30 bg-signal-downDim px-4 py-2 text-xs text-signal-down">
            {error}
          </div>
        </div>
      )}

      <main className="mx-auto max-w-[1400px] px-6 py-8">
        {!hasAddresses ? (
          <div className="flex min-h-[70vh] items-center justify-center">
            <WalletInput />
          </div>
        ) : (
          <div className="space-y-6">
            <PortfolioSummaryCards />

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <PnlChart />
              </div>
              <AllocationChart />
            </div>

            <TokenTable onSelect={setSelectedToken} />

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <AlertsPanel />
              <HistoryPanel />
            </div>

            <div className="pt-4">
              <WalletInput />
            </div>
          </div>
        )}
      </main>

      <TokenDetailDrawer token={selectedToken} onClose={() => setSelectedToken(null)} />
    </div>
  );
}
