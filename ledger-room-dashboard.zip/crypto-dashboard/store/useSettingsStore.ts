"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

interface SettingsState {
  mode: "dark" | "light";
  toggleMode: () => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set, get) => ({
      mode: "dark",
      toggleMode: () => {
        const next = get().mode === "dark" ? "light" : "dark";
        document.documentElement.classList.remove("dark", "light");
        document.documentElement.classList.add(next);
        set({ mode: next });
      }
    }),
    { name: "ledgerroom-theme" }
  )
);
