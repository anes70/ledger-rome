"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type {
  AlertRule,
  ChainId,
  HistoryEntry,
  PortfolioSnapshot,
  TokenPosition,
  WalletAddresses
} from "@/lib/types";
import { uid } from "@/lib/utils";

function tokenKey(chain: ChainId, address: string): string {
  return `${chain}:${address}`;
}

interface PortfolioState {
  addresses: WalletAddresses;
  tokens: TokenPosition[];
  loading: boolean;
  error: string | null;
  lastUpdated: number | null;

  costBasis: Record<string, number>; // key = "chain:address" -> prix moyen d'achat
  favorites: Record<string, true>;
  tags: Record<string, string[]>;
  notes: Record<string, string>;
  alerts: AlertRule[];
  history: HistoryEntry[];
  snapshots: PortfolioSnapshot[];

  setAddresses: (addresses: WalletAddresses) => void;
  refresh: () => Promise<void>;
  setCostBasis: (chain: ChainId, address: string, price: number) => void;
  toggleFavorite: (chain: ChainId, address: string) => void;
  setTags: (chain: ChainId, address: string, tags: string[]) => void;
  setNote: (chain: ChainId, address: string, note: string) => void;

  addAlert: (alert: Omit<AlertRule, "id" | "createdAt" | "triggeredAt" | "active">) => void;
  removeAlert: (id: string) => void;
  toggleAlert: (id: string) => void;
  checkAlerts: () => AlertRule[]; // renvoie les alertes qui viennent de se declencher
}

export const usePortfolioStore = create<PortfolioState>()(
  persist(
    (set, get) => ({
      addresses: { solana: [], base: [] },
      tokens: [],
      loading: false,
      error: null,
      lastUpdated: null,

      costBasis: {},
      favorites: {},
      tags: {},
      notes: {},
      alerts: [],
      history: [],
      snapshots: [],

      setAddresses: (addresses) => set({ addresses }),

      refresh: async () => {
        const { addresses, costBasis, tokens: previousTokens, history } = get();
        if (addresses.solana.length === 0 && addresses.base.length === 0) return;

        set({ loading: true, error: null });
        try {
          const res = await fetch("/api/portfolio", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ addresses, costBasis })
          });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error || "Erreur inconnue");

          const newTokens: TokenPosition[] = data.positions;

          // Detection automatique : ventes (tokens disparus) et nouvelles positions.
          const prevKeys = new Set(previousTokens.map((t) => tokenKey(t.chain, t.address)));
          const newKeys = new Set(newTokens.map((t) => tokenKey(t.chain, t.address)));
          const newHistoryEntries: HistoryEntry[] = [];

          for (const t of previousTokens) {
            if (!newKeys.has(tokenKey(t.chain, t.address))) {
              newHistoryEntries.push({
                id: uid(),
                timestamp: Date.now(),
                type: "vente",
                tokenSymbol: t.symbol,
                chain: t.chain,
                quantity: t.quantity,
                priceUsd: t.priceUsd,
                note: "Position disparue du portefeuille (vente ou transfert detecte automatiquement)."
              });
            }
          }
          for (const t of newTokens) {
            if (!prevKeys.has(tokenKey(t.chain, t.address)) && previousTokens.length > 0) {
              newHistoryEntries.push({
                id: uid(),
                timestamp: Date.now(),
                type: "achat",
                tokenSymbol: t.symbol,
                chain: t.chain,
                quantity: t.quantity,
                priceUsd: t.priceUsd,
                note: "Nouvelle position detectee automatiquement."
              });
            }
          }

          // Merge favoris/tags/notes (deja stockes par cle chain:address, rien a faire) + attache au token.
          const { favorites, tags, notes } = get();
          const enriched = newTokens.map((t) => {
            const key = tokenKey(t.chain, t.address);
            return {
              ...t,
              isFavorite: Boolean(favorites[key]),
              tags: tags[key] || [],
              notes: notes[key] || ""
            };
          });

          const totalValueUsd = enriched.reduce((sum, t) => sum + (t.valueUsd ?? 0), 0);
          const snapshots = [...get().snapshots, { timestamp: Date.now(), totalValueUsd }].slice(-500);

          set({
            tokens: enriched,
            loading: false,
            lastUpdated: Date.now(),
            history: [...newHistoryEntries, ...history].slice(0, 500),
            snapshots
          });
        } catch (err) {
          set({ loading: false, error: err instanceof Error ? err.message : "Erreur de recuperation du portefeuille." });
        }
      },

      setCostBasis: (chain, address, price) => {
        const key = tokenKey(chain, address);
        set({ costBasis: { ...get().costBasis, [key]: price } });
      },

      toggleFavorite: (chain, address) => {
        const key = tokenKey(chain, address);
        const favorites = { ...get().favorites };
        if (favorites[key]) delete favorites[key];
        else favorites[key] = true;
        set({
          favorites,
          tokens: get().tokens.map((t) =>
            tokenKey(t.chain, t.address) === key ? { ...t, isFavorite: Boolean(favorites[key]) } : t
          )
        });
      },

      setTags: (chain, address, newTags) => {
        const key = tokenKey(chain, address);
        set({
          tags: { ...get().tags, [key]: newTags },
          tokens: get().tokens.map((t) => (tokenKey(t.chain, t.address) === key ? { ...t, tags: newTags } : t))
        });
      },

      setNote: (chain, address, note) => {
        const key = tokenKey(chain, address);
        set({
          notes: { ...get().notes, [key]: note },
          tokens: get().tokens.map((t) => (tokenKey(t.chain, t.address) === key ? { ...t, notes: note } : t))
        });
      },

      addAlert: (alert) => {
        const newAlert: AlertRule = { ...alert, id: uid(), active: true, createdAt: Date.now(), triggeredAt: null };
        set({ alerts: [newAlert, ...get().alerts] });
      },
      removeAlert: (id) => set({ alerts: get().alerts.filter((a) => a.id !== id) }),
      toggleAlert: (id) =>
        set({ alerts: get().alerts.map((a) => (a.id === id ? { ...a, active: !a.active } : a)) }),

      checkAlerts: () => {
        const { alerts, tokens } = get();
        const triggered: AlertRule[] = [];
        const updated = alerts.map((alert) => {
          if (!alert.active || alert.triggeredAt) return alert;
          const token = tokens.find((t) => t.chain === alert.chain && t.address === alert.tokenAddress);
          if (!token) return alert;

          let hit = false;
          if (alert.type === "prix_au_dessus" && token.priceUsd !== null) hit = token.priceUsd >= alert.threshold;
          if (alert.type === "prix_en_dessous" && token.priceUsd !== null) hit = token.priceUsd <= alert.threshold;
          if (alert.type === "rsi_survente" && token.indicators?.rsi14 !== null && token.indicators?.rsi14 !== undefined)
            hit = token.indicators.rsi14 <= alert.threshold;
          if (alert.type === "rsi_surachat" && token.indicators?.rsi14 !== null && token.indicators?.rsi14 !== undefined)
            hit = token.indicators.rsi14 >= alert.threshold;
          if (alert.type === "chute_liquidite" && token.liquidityUsd !== null) hit = token.liquidityUsd <= alert.threshold;
          if (alert.type === "variation_24h" && token.priceChange24h !== null) hit = Math.abs(token.priceChange24h) >= alert.threshold;

          if (hit) {
            const withTrigger = { ...alert, triggeredAt: Date.now() };
            triggered.push(withTrigger);
            return withTrigger;
          }
          return alert;
        });
        if (triggered.length > 0) set({ alerts: updated });
        return triggered;
      }
    }),
    {
      name: "ledgerroom-portfolio",
      partialize: (state) => ({
        addresses: state.addresses,
        costBasis: state.costBasis,
        favorites: state.favorites,
        tags: state.tags,
        notes: state.notes,
        alerts: state.alerts,
        history: state.history,
        snapshots: state.snapshots,
        tokens: state.tokens,
        lastUpdated: state.lastUpdated
      })
    }
  )
);
