/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: ce fichier est regenere automatiquement par `next dev` / `next build`.
// Ne pas le modifier a la main.
