# Ledger Room — Dashboard Crypto (Base & Solana)

Tableau de bord crypto professionnel : suivi automatique de portefeuille sur **Base** et **Solana**, analyse technique, IA explicable, analyse sociale et alertes intelligentes.

**100% gratuit par defaut.** Aucune cle API n'est requise pour faire fonctionner l'application : elle s'appuie sur des RPC publics (Solana, Base) et des APIs gratuites (CoinGecko, DexScreener, DeFiLlama, Reddit, GitHub). Ajouter des cles dans `.env.local` debloque simplement plus de profondeur de donnees (voir plus bas).

---

## 1. Ce que fait reellement l'application (important a lire)

Aucune donnee n'est simulee. Chaque metrique affichee provient d'un appel reel a une API publique. Concretement :

| Fonctionnalite | Source | Statut |
|---|---|---|
| Solde SOL + tous les tokens SPL / Token-2022 | RPC public Solana | ✅ Gratuit, fonctionne immediatement |
| Solde ETH natif sur Base | RPC public Base | ✅ Gratuit, fonctionne immediatement |
| Liste complete des tokens ERC20 sur Base | Indexeur (Alchemy) | ⚠️ Necessite une cle **gratuite** Alchemy (voir §4) |
| Prix, variation, liquidite, volume, FDV, market cap | DexScreener + CoinGecko | ✅ Gratuit, sans cle |
| RSI, MACD, SMA, EMA, Bollinger, ATR, ADX, Fibonacci | Calcules localement (librairie `technicalindicators`) a partir de l'historique CoinGecko | ✅ Gratuit, sans cle |
| Repartition (token / chaine / secteur), PNL, evolution du portefeuille | Calcules localement | ✅ Gratuit |
| Recommandation IA (renforcer/vendre/attendre...) avec justification | Moteur heuristique deterministe, 100% local | ✅ Gratuit — voir §5 pour brancher un vrai LLM |
| Twitter/X abonnes, Reddit, sentiment, GitHub (stars/commits) | CoinGecko `community_data` + `developer_data`, recoupe avec Reddit/GitHub publics | ✅ Gratuit, sans cle |
| TVL de protocoles DeFi | DeFiLlama | ✅ Gratuit, sans cle |
| Telegram temps reel, Discord, tweets/engagement live, whales/smart money, holder count precis, unlocks/tokenomics detailles | Necessitent des indexeurs/API payants (Nansen, Arkham, Moralis Web3, X API Basic, bots Telegram/Discord dedies) | 🔒 Architecture prete, desactive par defaut — ajoutez vos cles pour les activer |

Le principe suivi partout dans le code : **si une donnee ne peut pas etre obtenue gratuitement et honnetement, elle affiche "—" ou un message explicite plutot que d'etre inventee.**

---

## 2. Installation

### Prerequis
- Node.js 18.17 ou superieur
- npm

### Etapes

```bash
# 1. Installer les dependances
npm install

# 2. Copier le fichier d'environnement (facultatif, l'app marche sans)
cp .env.example .env.local

# 3. Lancer en developpement
npm run dev
```

L'application est disponible sur **http://localhost:3000**.

### Build production

```bash
npm run build
npm start
```

---

## 3. Utilisation

1. A l'ouverture, entrez une ou plusieurs adresses publiques (Solana et/ou Base), ou connectez un wallet navigateur (Phantom, Backpack, MetaMask, Coinbase Wallet). **Aucune cle privee n'est jamais demandee.**
2. Cliquez sur **Charger le portefeuille**.
3. Le tableau de bord recupere automatiquement tous vos tokens, leurs prix, votre valorisation totale et la repartition.
4. Cliquez sur un token pour ouvrir le panneau detaille : indicateurs techniques, recommandation IA, donnees sociales, notes personnelles et prix moyen d'achat (pour activer le calcul de PNL).
5. Le bouton **Actualiser** (et l'auto-refresh toutes les 60 secondes) recupere les nouvelles donnees, fait disparaitre les tokens vendus et ajoute les nouvelles positions — tout est logue automatiquement dans l'**Historique**.
6. Configurez des **alertes** (prix, RSI, chute de liquidite, variation 24h) depuis le panneau dedie.

Toutes vos donnees personnelles (adresses, prix d'achat, favoris, tags, notes, alertes, historique) sont stockees **localement dans votre navigateur** (`localStorage`) — aucune base de donnees serveur n'est necessaire pour un usage 100% gratuit et prive.

---

## 4. Ajouter des cles API (facultatif)

Toutes les cles vont dans `.env.local` (jamais commit dans Git, jamais exposees au navigateur — tous les appels externes passent par les routes serveur `app/api/*`).

### Debloquer tous les tokens ERC20 sur Base (recommande)
1. Creez un compte gratuit sur https://www.alchemy.com
2. Creez une app "Base Mainnet"
3. Copiez la cle API dans `.env.local` :
   ```
   ALCHEMY_BASE_API_KEY=votre_cle
   ```

### Autres cles disponibles
Voir les commentaires dans `.env.example` pour Moralis, Covalent, Basescan, CoinGecko Pro, Birdeye, X API, Telegram Bot, Discord Bot — toutes optionnelles, toutes documentees.

---

## 5. Brancher une vraie IA (LLM) a la place du moteur heuristique

Le moteur actuel (`lib/aiEngine.ts`) est deterministe et gratuit : il applique des regles transparentes (RSI, tendance, liquidite, volatilite, PNL...) et explique chaque recommandation. Pour le remplacer par un LLM (ex. Claude API) :

1. Ajoutez votre cle API dans `.env.local` (ex. `ANTHROPIC_API_KEY=...`)
2. Dans `app/api/token/route.ts`, remplacez l'appel a `generateAdvice(...)` par un appel a votre fournisseur LLM, en lui passant les memes donnees (`indicators`, `priceHistory7d`, fondamentaux du token) et en lui demandant de repondre au meme format `AiAdvice` (voir `lib/types.ts`).
3. Gardez `generateAdvice` comme solution de repli (`fallback`) en cas d'erreur ou d'absence de cle, pour que l'app reste 100% fonctionnelle sans depense.

---

## 6. Ajouter une nouvelle blockchain (ex. Ethereum, Arbitrum, Polygon...)

L'architecture est prevue pour ca :

1. Ajoutez la chaine dans le type `ChainId` (`lib/types.ts`).
2. Creez `lib/services/<chaine>.ts` sur le modele de `lib/services/base.ts` (toutes les chaines EVM se ressemblent : reprenez `viem` avec la bonne chaine importee depuis `viem/chains`).
3. Ajoutez son RPC public dans `lib/config.ts`.
4. Branchez la nouvelle fonction d'agregation dans `lib/portfolio.ts` (fonction `aggregateBase` a dupliquer/generaliser).
5. Ajoutez l'entree correspondante dans `NATIVE_META` (`lib/portfolio.ts`) et `NATIVE_PROXY_ADDRESS` (`lib/services/dexscreener.ts`) — DexScreener et CoinGecko supportent deja la plupart des chaines listees dans le cahier des charges (Arbitrum, Optimism, BNB Chain, Avalanche, Polygon...).
6. Ajoutez un bouton de filtre dans `components/TokenTable.tsx` et `components/WalletInput.tsx`.

---

## 7. Ajouter une nouvelle API de donnees

Tous les services externes vivent dans `lib/services/*.ts`, avec un pattern commun :
- Un cache memoire via `cached()` (`lib/utils.ts`) pour respecter les limites de taux gratuites.
- Un `fetchJson()` avec timeout et gestion d'erreur.
- Jamais d'appel direct cote client — toujours via une route `app/api/*` pour ne jamais exposer de cle.

Pour ajouter une source (ex. Birdeye pour des donnees Solana plus riches) : creez `lib/services/birdeye.ts` sur ce modele, puis appelez-le depuis `lib/portfolio.ts` ou une route API dediee.

---

## 8. Deploiement

### Vercel (le plus simple, gratuit pour un usage personnel)
1. Poussez ce projet sur GitHub.
2. Importez le repo sur https://vercel.com/new
3. Ajoutez vos variables d'environnement (facultatif) dans les parametres du projet.
4. Deployez — c'est tout, Next.js est nativement supporte.

### Railway
1. Creez un nouveau projet sur https://railway.app
2. Connectez le repo GitHub.
3. Railway detecte automatiquement Next.js (`npm run build` / `npm start`).
4. Ajoutez vos variables d'environnement dans l'onglet **Variables**.

### VPS (Docker)
```bash
cp .env.example .env.local   # remplissez si besoin
docker compose up -d --build
```
L'application est servie sur le port 3000 du serveur (proxifiez-la avec Nginx/Caddy pour du HTTPS).

---

## 9. Architecture du projet

```
app/
  layout.tsx              Layout racine (polices, theme)
  page.tsx                Page unique du dashboard
  globals.css              Design tokens (glassmorphism, couleurs signal)
  api/
    portfolio/route.ts     Agregation complete du portefeuille
    token/route.ts         Indicateurs techniques + recommandation IA d'un token
    social/route.ts        Donnees sociales/communautaires d'un token

components/                Composants React (UI, graphiques, panneaux)
  ui/                      Primitives (Card, Badge, Skeleton)

lib/
  types.ts                 Types TypeScript partages
  config.ts                Configuration centrale (cles, endpoints, cache)
  utils.ts                 Cache memoire, fetch, formatage
  indicators.ts             Moteur d'indicateurs techniques
  aiEngine.ts               Moteur IA explicable (heuristique, gratuit)
  portfolio.ts               Orchestrateur d'agregation du portefeuille
  pnl.ts                     Calcul du PNL sur des periodes
  services/
    solana.ts                RPC Solana (soldes natifs + SPL)
    base.ts                   RPC Base (ETH natif + ERC20 via indexeur optionnel)
    dexscreener.ts             Prix/liquidite/volume temps reel
    coingecko.ts                Fondamentaux, communaute, developpeur, historique de prix
    social.ts                    Agregation sociale (Twitter/Reddit/Telegram/GitHub/sentiment)
    defillama.ts                  TVL des protocoles

store/
  usePortfolioStore.ts      Etat global (zustand, persiste en localStorage)
  useSettingsStore.ts        Theme clair/sombre
```

---

## 10. Securite

- **Jamais de cle privee** demandee ni stockee : uniquement des adresses publiques ou une connexion wallet navigateur (qui ne partage que l'adresse publique).
- Toutes les cles API sensibles restent **cote serveur** (`.env.local`, jamais envoyees au navigateur).
- Toutes les entrees utilisateur (adresses) sont validees par regex avant tout appel externe (`app/api/portfolio/route.ts`).
- Aucune injection de script possible : React echappe tout le contenu par defaut (protection XSS native).
- Les routes API sont `POST` uniquement avec validation de payload, pas de secrets en query string.

---

## 11. Stack technique

Next.js 14 (App Router) · TypeScript · TailwindCSS · Framer Motion · Zustand · Recharts · `@solana/web3.js` · `viem` · `technicalindicators` · `date-fns` · `lucide-react`

Toutes ces librairies sont open-source et gratuites.
