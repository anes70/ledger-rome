import { getSolanaBalances } from "@/lib/services/solana";
import { getBaseNativeBalance, getBaseErc20Balances } from "@/lib/services/base";
import { getDexScreenerToken, NATIVE_PROXY_ADDRESS } from "@/lib/services/dexscreener";
import { getCoinByContract, extractSector } from "@/lib/services/coingecko";
import type { ChainId, TokenPosition, WalletAddresses } from "@/lib/types";

const NATIVE_META: Record<ChainId, { symbol: string; name: string; coingeckoId: string; logo: string }> = {
  solana: {
    symbol: "SOL",
    name: "Solana",
    coingeckoId: "solana",
    logo: "https://assets.coingecko.com/coins/images/4128/small/solana.png"
  },
  base: {
    symbol: "ETH",
    name: "Ethereum",
    coingeckoId: "ethereum",
    logo: "https://assets.coingecko.com/coins/images/279/small/ethereum.png"
  }
};

interface AggregatedRaw {
  chain: ChainId;
  address: string; // "native" ou adresse de contrat
  quantity: number;
  decimals: number;
}

async function aggregateSolana(addresses: string[]): Promise<AggregatedRaw[]> {
  const map = new Map<string, AggregatedRaw>();
  for (const addr of addresses) {
    if (!addr.trim()) continue;
    try {
      const balances = await getSolanaBalances(addr.trim());
      for (const b of balances) {
        if (b.amount <= 0) continue;
        const key = b.mint;
        const existing = map.get(key);
        if (existing) existing.quantity += b.amount;
        else map.set(key, { chain: "solana", address: b.mint, quantity: b.amount, decimals: b.decimals });
      }
    } catch (err) {
      console.error(`[portfolio] Echec recuperation Solana pour ${addr}:`, err);
    }
  }
  return Array.from(map.values());
}

async function aggregateBase(addresses: string[]): Promise<AggregatedRaw[]> {
  const map = new Map<string, AggregatedRaw>();
  for (const addr of addresses) {
    if (!addr.trim()) continue;
    const typed = addr.trim() as `0x${string}`;
    try {
      const native = await getBaseNativeBalance(typed);
      if (native.amount > 0) {
        const existing = map.get("native");
        if (existing) existing.quantity += native.amount;
        else map.set("native", { chain: "base", address: "native", quantity: native.amount, decimals: 18 });
      }
      const erc20 = await getBaseErc20Balances(typed);
      for (const t of erc20) {
        if (t.amount <= 0) continue;
        const key = t.contract.toLowerCase();
        const existing = map.get(key);
        if (existing) existing.quantity += t.amount;
        else map.set(key, { chain: "base", address: key, quantity: t.amount, decimals: t.decimals });
      }
    } catch (err) {
      console.error(`[portfolio] Echec recuperation Base pour ${addr}:`, err);
    }
  }
  return Array.from(map.values());
}

/**
 * Construit le portefeuille complet a partir des adresses fournies.
 * Chaque token est enrichi avec des donnees de marche REELLES (DexScreener + CoinGecko).
 * Les indicateurs techniques / donnees sociales detaillees sont charges a la demande
 * (voir /api/token/[address]) pour rester rapide et economiser le rate-limit gratuit.
 */
export async function buildPortfolio(
  addresses: WalletAddresses,
  costBasis: Record<string, number>
): Promise<TokenPosition[]> {
  const [solanaRaw, baseRaw] = await Promise.all([
    aggregateSolana(addresses.solana),
    aggregateBase(addresses.base)
  ]);

  const raw = [...solanaRaw, ...baseRaw];

  const positions = await Promise.all(
    raw.map(async (r): Promise<TokenPosition | null> => {
      const isNative = r.address === "native";
      const dexAddress = isNative ? NATIVE_PROXY_ADDRESS[r.chain] : r.address;

      const [dexData, cgData] = await Promise.all([
        getDexScreenerToken(r.chain, dexAddress).catch(() => null),
        isNative ? Promise.resolve(null) : getCoinByContract(r.chain, r.address).catch(() => null)
      ]);

      const meta = isNative ? NATIVE_META[r.chain] : null;

      const symbol = dexData?.symbol || meta?.symbol || cgData?.symbol?.toUpperCase() || "?";
      const name = dexData?.name || meta?.name || cgData?.name || "Token inconnu";
      const logo = meta?.logo || dexData?.logo || cgData?.image?.small || null;
      const priceUsd = cgData?.market_data?.current_price?.usd ?? dexData?.priceUsd ?? null;

      if (priceUsd === null && dexData === null && !meta) {
        // Aucune source n'a reconnu ce token : on l'affiche quand meme avec des donnees minimales
        // plutot que de le faire disparaitre silencieusement (transparence > confort).
      }

      const valueUsd = priceUsd !== null ? priceUsd * r.quantity : null;
      const avgBuyPrice = costBasis[`${r.chain}:${r.address}`] ?? null;
      const pnlUsd = avgBuyPrice !== null && valueUsd !== null ? valueUsd - avgBuyPrice * r.quantity : null;
      const pnlPct = avgBuyPrice !== null && avgBuyPrice > 0 && priceUsd !== null
        ? ((priceUsd - avgBuyPrice) / avgBuyPrice) * 100
        : null;

      const position: TokenPosition = {
        chain: r.chain,
        address: r.address,
        symbol,
        name,
        logo,
        quantity: r.quantity,
        decimals: r.decimals,

        priceUsd,
        priceChange1h: dexData?.priceChange1h ?? null,
        priceChange24h: dexData?.priceChange24h ?? cgData?.market_data?.price_change_percentage_24h ?? null,
        priceChange7d: cgData?.market_data?.price_change_percentage_7d ?? null,
        ath: cgData?.market_data?.ath?.usd ?? null,
        atl: cgData?.market_data?.atl?.usd ?? null,

        valueUsd,

        avgBuyPrice,
        pnlUsd,
        pnlPct,

        liquidityUsd: dexData?.liquidityUsd ?? null,
        volume24hUsd: dexData?.volume24hUsd ?? null,
        fdvUsd: dexData?.fdvUsd ?? cgData?.market_data?.fully_diluted_valuation?.usd ?? null,
        marketCapUsd: dexData?.marketCapUsd ?? cgData?.market_data?.market_cap?.usd ?? null,
        supply: cgData?.market_data?.total_supply ?? null,
        circulatingSupply: cgData?.market_data?.circulating_supply ?? null,

        coingeckoId: cgData?.id ?? meta?.coingeckoId ?? null,
        sector: extractSector(cgData?.categories),
        ageInDays: dexData?.ageInDays ?? null,

        priceHistory7d: [],
        indicators: null
      };

      return position;
    })
  );

  return positions
    .filter((p): p is TokenPosition => p !== null && p.quantity > 0)
    .sort((a, b) => (b.valueUsd ?? 0) - (a.valueUsd ?? 0));
}
