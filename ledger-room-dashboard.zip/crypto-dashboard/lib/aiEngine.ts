import type { AiAdvice, AiAction, Indicators, PriceHistoryPoint } from "@/lib/types";

export interface AiEngineInput {
  priceUsd: number | null;
  priceChange24h: number | null;
  priceChange7d: number | null;
  liquidityUsd: number | null;
  volume24hUsd: number | null;
  marketCapUsd: number | null;
  ageInDays: number | null;
  avgBuyPrice: number | null;
  pnlPct: number | null;
  indicators: Indicators | null;
  priceHistory7d: PriceHistoryPoint[];
}

function stdDevPct(history: PriceHistoryPoint[]): number | null {
  if (history.length < 3) return null;
  const prices = history.map((h) => h.price);
  const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
  const variance = prices.reduce((a, b) => a + (b - mean) ** 2, 0) / prices.length;
  const std = Math.sqrt(variance);
  return mean > 0 ? (std / mean) * 100 : null;
}

/**
 * Moteur IA explicable, 100% deterministe et gratuit (aucun appel a une API payante).
 * Chaque recommandation est justifiee par des valeurs reellement calculees — jamais de texte generique.
 * Architecture prete a etre remplacee/enrichie par un vrai LLM (ex: Claude API) : voir README.
 */
export function generateAdvice(input: AiEngineInput): AiAdvice {
  const reasoning: string[] = [];
  let risk = 40;
  let confidence = 40;
  let potential = 40;
  let reinforcementScore = 40;

  const rsi = input.indicators?.rsi14 ?? null;
  const trend = input.indicators?.trend ?? "neutre";
  const volatility = stdDevPct(input.priceHistory7d);

  // --- Risque ---
  if (input.liquidityUsd !== null) {
    if (input.liquidityUsd < 20_000) {
      risk += 30;
      reasoning.push(`Liquidite tres faible (${Math.round(input.liquidityUsd).toLocaleString("fr-FR")} $) : risque eleve de slippage important a la revente.`);
    } else if (input.liquidityUsd < 150_000) {
      risk += 12;
      reasoning.push("Liquidite moderee : les ordres de grande taille peuvent impacter le prix.");
    } else {
      risk -= 10;
      reasoning.push("Liquidite confortable, sortie de position facilitee.");
    }
  }

  if (input.ageInDays !== null && input.ageInDays < 14) {
    risk += 20;
    reasoning.push(`Projet tres recent (${input.ageInDays} jours) : historique insuffisant pour juger de sa solidite.`);
  }

  if (volatility !== null) {
    if (volatility > 25) {
      risk += 15;
      reasoning.push(`Volatilite 7 jours elevee (${volatility.toFixed(1)}%) : mouvements de prix brusques probables.`);
    } else if (volatility < 8) {
      risk -= 8;
      reasoning.push(`Volatilite 7 jours contenue (${volatility.toFixed(1)}%).`);
    }
  }

  // --- Tendance / momentum ---
  if (rsi !== null) {
    if (rsi > 70) {
      reasoning.push(`RSI a ${rsi.toFixed(0)} : zone de surachat, un retracement a court terme est possible.`);
      potential -= 10;
    } else if (rsi < 30) {
      reasoning.push(`RSI a ${rsi.toFixed(0)} : zone de survente, rebond technique possible.`);
      potential += 12;
    } else {
      reasoning.push(`RSI a ${rsi.toFixed(0)} : pas de signal extreme.`);
    }
  }

  if (trend === "haussier") {
    reasoning.push("Le prix evolue au-dessus de sa moyenne mobile 20 periodes : structure haussiere a court terme.");
    potential += 10;
    confidence += 10;
  } else if (trend === "baissier") {
    reasoning.push("Le prix evolue en dessous de sa moyenne mobile 20 periodes : structure baissiere a court terme.");
    potential -= 10;
    confidence += 5;
  }

  if (input.indicators?.macd) {
    const { histogram } = input.indicators.macd;
    if (histogram > 0) reasoning.push("Histogramme MACD positif : momentum acheteur.");
    else if (histogram < 0) reasoning.push("Histogramme MACD negatif : momentum vendeur.");
  }

  // --- PNL utilisateur (si prix moyen d'achat renseigne) ---
  let action: AiAction = "CONSERVER";
  if (input.pnlPct !== null && input.avgBuyPrice !== null) {
    if (input.pnlPct >= 80) {
      action = "PRENDRE_PROFIT";
      reasoning.push(`Plus-value de ${input.pnlPct.toFixed(0)}% depuis le prix moyen d'achat : securiser une partie des gains est une option raisonnable.`);
    } else if (input.pnlPct <= -35) {
      action = "COUPER_PERTE";
      reasoning.push(`Perte latente de ${Math.abs(input.pnlPct).toFixed(0)}% : reevaluer la these d'investissement s'impose.`);
    }
  }

  // --- Decision finale (si aucun signal de PNL n'a deja tranche) ---
  if (action === "CONSERVER") {
    if (risk > 75) {
      action = "EVITER";
      reasoning.push("Le niveau de risque global est trop eleve pour une nouvelle exposition.");
    } else if (rsi !== null && rsi < 30 && trend !== "baissier") {
      action = "RENFORCER";
      reinforcementScore += 20;
    } else if (rsi !== null && rsi > 75) {
      action = "ATTENDRE";
    } else if (trend === "baissier" && risk > 55) {
      action = "VENDRE";
      reasoning.push("Structure baissiere combinee a un risque eleve : la prudence prevaut.");
    }
  }

  risk = Math.max(0, Math.min(100, risk));
  confidence = Math.max(0, Math.min(100, confidence + (input.priceHistory7d.length >= 100 ? 15 : 0)));
  potential = Math.max(0, Math.min(100, potential));
  reinforcementScore = Math.max(0, Math.min(100, reinforcementScore - risk * 0.3));

  const price = input.priceUsd;
  const atr = input.indicators?.atr14;
  const stopLoss = price !== null && atr ? Number((price - atr * 1.5).toFixed(8)) : price !== null ? Number((price * 0.85).toFixed(8)) : null;
  const takeProfit = price !== null && atr ? Number((price + atr * 2.5).toFixed(8)) : price !== null ? Number((price * 1.4).toFixed(8)) : null;

  const fib = input.indicators?.fibonacci;
  const buyZone = fib ? { low: fib.level618, high: fib.level5 } : null;
  const sellZone = fib ? { low: fib.level236, high: fib.level1 } : null;

  if (reasoning.length === 0) {
    reasoning.push("Historique de donnees insuffisant pour une analyse technique detaillee — recommandation basee sur les fondamentaux disponibles uniquement.");
  }

  return {
    action,
    confidence: Math.round(confidence),
    risk: Math.round(risk),
    potential: Math.round(potential),
    reinforcementScore: Math.round(reinforcementScore),
    horizon: risk > 60 ? "court terme" : risk > 35 ? "moyen terme" : "long terme",
    priceTarget: takeProfit,
    stopLoss,
    takeProfit,
    buyZone,
    sellZone,
    reasoning
  };
}
