import type { PortfolioSnapshot } from "@/lib/types";

export interface PnlResult {
  absolute: number;
  pct: number;
}

/**
 * Cherche le snapshot le plus proche de `msAgo` millisecondes dans le passe
 * et calcule la variation par rapport a la valeur actuelle.
 * Renvoie `null` tant que l'historique local n'est pas assez profond —
 * jamais de donnee inventee.
 */
export function computePnlSince(
  snapshots: PortfolioSnapshot[],
  currentValue: number,
  msAgo: number
): PnlResult | null {
  if (snapshots.length === 0) return null;
  const targetTime = Date.now() - msAgo;
  const oldest = snapshots[0];
  if (oldest.timestamp > targetTime) return null; // pas encore assez d'historique local

  let closest = snapshots[0];
  for (const snap of snapshots) {
    if (Math.abs(snap.timestamp - targetTime) < Math.abs(closest.timestamp - targetTime)) {
      closest = snap;
    }
  }

  if (closest.totalValueUsd === 0) return null;
  const absolute = currentValue - closest.totalValueUsd;
  const pct = (absolute / closest.totalValueUsd) * 100;
  return { absolute, pct };
}
