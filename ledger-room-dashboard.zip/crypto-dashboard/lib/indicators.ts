import { RSI, MACD, SMA, EMA, BollingerBands, ATR, ADX } from "technicalindicators";
import type { Indicators, PriceHistoryPoint } from "@/lib/types";

/**
 * Calcule l'ensemble des indicateurs techniques a partir d'un historique de prix.
 * Necessite au moins ~30 points pour des resultats fiables ; renvoie des valeurs
 * nulles (jamais inventees) si l'historique est insuffisant.
 */
export function computeIndicators(history: PriceHistoryPoint[]): Indicators {
  const closes = history.map((h) => h.price);

  const empty: Indicators = {
    rsi14: null,
    sma20: null,
    sma50: null,
    ema20: null,
    ema50: null,
    macd: null,
    bollinger: null,
    atr14: null,
    adx14: null,
    vwap: null,
    fibonacci: null,
    trend: "neutre"
  };

  if (closes.length < 15) return empty;

  const rsiValues = RSI.calculate({ period: 14, values: closes });
  const sma20Values = SMA.calculate({ period: Math.min(20, closes.length - 1), values: closes });
  const sma50Values = closes.length > 50 ? SMA.calculate({ period: 50, values: closes }) : [];
  const ema20Values = EMA.calculate({ period: Math.min(20, closes.length - 1), values: closes });
  const ema50Values = closes.length > 50 ? EMA.calculate({ period: 50, values: closes }) : [];
  const macdValues = MACD.calculate({
    values: closes,
    fastPeriod: 12,
    slowPeriod: 26,
    signalPeriod: 9,
    SimpleMAOscillator: false,
    SimpleMASignal: false
  });
  const bbValues = BollingerBands.calculate({ period: Math.min(20, closes.length - 1), values: closes, stdDev: 2 });

  // ATR / ADX necessitent high/low : sans donnees intrajournalieres detaillees, on approxime
  // high/low a partir du close (ecart type glissant) — signale honnetement comme approximation.
  const approxHigh = closes.map((c, i) => (i === 0 ? c : Math.max(c, closes[i - 1])));
  const approxLow = closes.map((c, i) => (i === 0 ? c : Math.min(c, closes[i - 1])));
  const atrValues = ATR.calculate({ period: 14, high: approxHigh, low: approxLow, close: closes });
  const adxValues = ADX.calculate({ period: 14, close: closes, high: approxHigh, low: approxLow });

  const last = <T,>(arr: T[]): T | null => (arr.length > 0 ? arr[arr.length - 1] : null);

  const macdLast = last(macdValues);
  const bbLast = last(bbValues);
  const adxLast = last(adxValues);

  const high = Math.max(...closes);
  const low = Math.min(...closes);
  const diff = high - low;

  const rsi = last(rsiValues);
  const sma20 = last(sma20Values);
  const currentPrice = closes[closes.length - 1];

  let trend: Indicators["trend"] = "neutre";
  if (sma20 !== null) {
    if (currentPrice > sma20 * 1.01) trend = "haussier";
    else if (currentPrice < sma20 * 0.99) trend = "baissier";
  }

  return {
    rsi14: rsi ?? null,
    sma20: sma20 ?? null,
    sma50: last(sma50Values),
    ema20: last(ema20Values),
    ema50: last(ema50Values),
    macd: macdLast
      ? { macd: macdLast.MACD ?? 0, signal: macdLast.signal ?? 0, histogram: macdLast.histogram ?? 0 }
      : null,
    bollinger: bbLast ? { upper: bbLast.upper, middle: bbLast.middle, lower: bbLast.lower } : null,
    atr14: last(atrValues),
    adx14: adxLast ? adxLast.adx : null,
    vwap: null, // VWAP necessite le volume par bougie (non fourni par l'historique gratuit CoinGecko)
    fibonacci: {
      level0: low,
      level236: low + diff * 0.236,
      level382: low + diff * 0.382,
      level5: low + diff * 0.5,
      level618: low + diff * 0.618,
      level786: low + diff * 0.786,
      level1: high
    },
    trend
  };
}
