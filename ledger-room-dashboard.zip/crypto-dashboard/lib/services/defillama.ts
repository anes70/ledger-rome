import { config } from "@/lib/config";
import { cached, fetchJson } from "@/lib/utils";

interface LlamaProtocol {
  name: string;
  symbol: string;
  tvl: number;
  chains: string[];
}

let protocolsCache: LlamaProtocol[] | null = null;

/** Charge la liste complete des protocoles DeFiLlama (gratuit, sans cle) et la garde en memoire. */
async function loadProtocols(): Promise<LlamaProtocol[]> {
  if (protocolsCache) return protocolsCache;
  try {
    const data = await fetchJson<LlamaProtocol[]>(`${config.endpoints.defillama}/protocols`);
    protocolsCache = data;
    return data;
  } catch {
    return [];
  }
}

/** Cherche le TVL d'un protocole par symbole de token (approximatif : correspondance sur le ticker). */
export async function getTvlBySymbol(symbol: string): Promise<number | null> {
  const key = `defillama-tvl:${symbol.toUpperCase()}`;
  return cached(key, config.cache.tokenDetailTtlMs, async () => {
    const protocols = await loadProtocols();
    const match = protocols.find((p) => p.symbol?.toUpperCase() === symbol.toUpperCase());
    return match ? match.tvl : null;
  });
}
