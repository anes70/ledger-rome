import { config } from "@/lib/config";
import { cached, fetchJson } from "@/lib/utils";
import { getCoinByContract, getCoinById } from "@/lib/services/coingecko";
import type { ChainId, SocialData } from "@/lib/types";

interface RedditAbout {
  data: { subscribers?: number; accounts_active?: number };
}

interface GithubRepo {
  stargazers_count?: number;
  forks_count?: number;
}

interface GithubStats {
  commits4Weeks: number;
}

async function getRedditStats(subredditUrl: string): Promise<{ subscribers: number | null; active: number | null }> {
  try {
    const slug = subredditUrl.replace(/\/$/, "").split("/").pop();
    if (!slug) return { subscribers: null, active: null };
    const url = `${config.endpoints.reddit}/r/${slug}/about.json`;
    const data = await fetchJson<RedditAbout>(url);
    return { subscribers: data.data.subscribers ?? null, active: data.data.accounts_active ?? null };
  } catch {
    return { subscribers: null, active: null };
  }
}

async function getGithubStats(repoUrl: string): Promise<{ stars: number | null; forks: number | null }> {
  try {
    const match = repoUrl.match(/github\.com\/([^/]+)\/([^/]+)/);
    if (!match) return { stars: null, forks: null };
    const [, owner, repo] = match;
    const url = `${config.endpoints.github}/repos/${owner}/${repo.replace(/\.git$/, "")}`;
    const data = await fetchJson<GithubRepo>(url);
    return { stars: data.stargazers_count ?? null, forks: data.forks_count ?? null };
  } catch {
    return { stars: null, forks: null };
  }
}

/**
 * Analyse sociale complete d'un token.
 * - Twitter (abonnes), Reddit (abonnes + actifs), Telegram (membres), sentiment : via CoinGecko (gratuit).
 * - GitHub (stars/forks) : recoupe CoinGecko avec l'API GitHub publique (gratuite, sans cle).
 * - Telegram temps reel / Discord / X (tweets, engagement live) : necessitent des cles payantes,
 *   desactives par defaut (voir lib/config.ts) et clairement signales via `configured`.
 */
export async function getSocialData(chain: ChainId, tokenAddress: string, coingeckoIdHint?: string | null): Promise<SocialData> {
  const key = `social:${chain}:${tokenAddress}`;
  return cached(key, config.cache.socialTtlMs, async () => {
    const coin = coingeckoIdHint
      ? await getCoinById(coingeckoIdHint)
      : await getCoinByContract(chain, tokenAddress);

    const empty: SocialData = {
      coingeckoId: null,
      twitterFollowers: null,
      redditSubscribers: null,
      redditActiveUsers: null,
      telegramUsers: null,
      sentimentUpPct: null,
      sentimentDownPct: null,
      githubStars: null,
      githubForks: null,
      githubCommitsLast4Weeks: null,
      links: { twitter: null, reddit: null, telegram: null, github: null, homepage: null },
      configured: {
        twitter: Boolean(config.keys.twitterBearer),
        telegram: Boolean(config.keys.telegramBotToken),
        discord: Boolean(config.keys.discordBotToken)
      }
    };

    if (!coin) return empty;

    const twitterHandle = coin.links?.twitter_screen_name || null;
    const redditUrl = coin.links?.subreddit_url || null;
    const githubUrl = coin.links?.repos_url?.github?.[0] || null;
    const homepage = coin.links?.homepage?.[0] || null;

    const [reddit, github] = await Promise.all([
      redditUrl ? getRedditStats(redditUrl) : Promise.resolve({ subscribers: null, active: null }),
      githubUrl ? getGithubStats(githubUrl) : Promise.resolve({ stars: null, forks: null })
    ]);

    return {
      coingeckoId: coin.id,
      twitterFollowers: coin.community_data?.twitter_followers ?? null,
      redditSubscribers: coin.community_data?.reddit_subscribers ?? reddit.subscribers,
      redditActiveUsers: coin.community_data?.reddit_accounts_active_48h ?? reddit.active,
      telegramUsers: coin.community_data?.telegram_channel_user_count ?? null,
      sentimentUpPct: coin.sentiment_votes_up_percentage ?? null,
      sentimentDownPct: coin.sentiment_votes_down_percentage ?? null,
      githubStars: coin.developer_data?.stars ?? github.stars,
      githubForks: coin.developer_data?.forks ?? github.forks,
      githubCommitsLast4Weeks: coin.developer_data?.commit_count_4_weeks ?? null,
      links: {
        twitter: twitterHandle ? `https://x.com/${twitterHandle}` : null,
        reddit: redditUrl,
        telegram: coin.links?.telegram_channel_identifier ? `https://t.me/${coin.links.telegram_channel_identifier}` : null,
        github: githubUrl,
        homepage
      },
      configured: empty.configured
    };
  });
}
