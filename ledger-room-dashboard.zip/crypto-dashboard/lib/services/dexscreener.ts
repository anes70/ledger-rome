import { config } from "@/lib/config";
import { cached, fetchJson } from "@/lib/utils";
import type { ChainId } from "@/lib/types";

interface DexScreenerPair {
  chainId: string;
  dexId: string;
  url: string;
  baseToken: { address: string; name: string; symbol: string };
  priceUsd: string;
  priceChange: { h1?: number; h24?: number; h6?: number };
  liquidity?: { usd?: number };
  volume?: { h24?: number };
  fdv?: number;
  marketCap?: number;
  pairCreatedAt?: number;
  info?: { imageUrl?: string };
}

interface DexScreenerResponse {
  pairs: DexScreenerPair[] | null;
}

export interface DexScreenerTokenSummary {
  address: string;
  symbol: string;
  name: string;
  logo: string | null;
  priceUsd: number | null;
  priceChange1h: number | null;
  priceChange24h: number | null;
  liquidityUsd: number | null;
  volume24hUsd: number | null;
  fdvUsd: number | null;
  marketCapUsd: number | null;
  ageInDays: number | null;
  pairsCount: number;
  dexUrl: string | null;
}

const chainIdMap: Record<ChainId, string> = {
  solana: "solana",
  base: "base"
};

/** Recupere les donnees de marche temps reel d'un token via l'API publique DexScreener (gratuite, sans cle). */
export async function getDexScreenerToken(
  chain: ChainId,
  tokenAddress: string
): Promise<DexScreenerTokenSummary | null> {
  const key = `dexscreener:${chain}:${tokenAddress}`;
  return cached(key, config.cache.priceTtlMs, async () => {
    const url = `${config.endpoints.dexscreener}/tokens/${tokenAddress}`;
    const data = await fetchJson<DexScreenerResponse>(url);
    if (!data.pairs || data.pairs.length === 0) return null;

    // On garde la paire avec le plus de liquidite sur la bonne chaine (donnee la plus fiable).
    const pairsOnChain = data.pairs.filter((p) => p.chainId === chainIdMap[chain]);
    const pool = pairsOnChain.length > 0 ? pairsOnChain : data.pairs;
    const best = pool.reduce((max, p) =>
      (p.liquidity?.usd ?? 0) > (max.liquidity?.usd ?? 0) ? p : max
    );

    const ageInDays = best.pairCreatedAt
      ? Math.floor((Date.now() - best.pairCreatedAt) / (1000 * 60 * 60 * 24))
      : null;

    return {
      address: tokenAddress,
      symbol: best.baseToken.symbol,
      name: best.baseToken.name,
      logo: best.info?.imageUrl ?? null,
      priceUsd: best.priceUsd ? Number(best.priceUsd) : null,
      priceChange1h: best.priceChange?.h1 ?? null,
      priceChange24h: best.priceChange?.h24 ?? null,
      liquidityUsd: best.liquidity?.usd ?? null,
      volume24hUsd: best.volume?.h24 ?? null,
      fdvUsd: best.fdv ?? null,
      marketCapUsd: best.marketCap ?? null,
      ageInDays,
      pairsCount: pool.length,
      dexUrl: best.url ?? null
    };
  });
}

/** Native tokens (SOL, ETH) n'ont pas d'adresse de contrat classique : on utilise leur wrapped address publique. */
export const NATIVE_PROXY_ADDRESS: Record<ChainId, string> = {
  solana: "So11111111111111111111111111111111111111", // Wrapped SOL
  base: "0x4200000000000000000000000000000000000006" // Wrapped ETH (Base)
};
