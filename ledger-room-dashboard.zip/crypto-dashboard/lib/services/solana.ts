import { Connection, PublicKey, LAMPORTS_PER_SOL } from "@solana/web3.js";
import { config } from "@/lib/config";

export interface RawSolanaBalance {
  mint: string; // "native" pour SOL
  amount: number;
  decimals: number;
}

let connection: Connection | null = null;
function getConnection(): Connection {
  if (!connection) {
    connection = new Connection(config.rpc.solana, "confirmed");
  }
  return connection;
}

/**
 * Recupere le solde natif SOL + tous les comptes de tokens SPL (>0) d'une adresse.
 * 100% gratuit : RPC public Solana, aucune cle requise.
 */
export async function getSolanaBalances(ownerAddress: string): Promise<RawSolanaBalance[]> {
  const conn = getConnection();
  const owner = new PublicKey(ownerAddress);

  const [lamports, tokenAccounts] = await Promise.all([
    conn.getBalance(owner, "confirmed"),
    conn.getParsedTokenAccountsByOwner(owner, {
      programId: new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")
    })
  ]);

  const balances: RawSolanaBalance[] = [
    { mint: "native", amount: lamports / LAMPORTS_PER_SOL, decimals: 9 }
  ];

  for (const { account } of tokenAccounts.value) {
    const info = account.data.parsed.info;
    const amount = Number(info.tokenAmount.uiAmount ?? 0);
    if (amount > 0) {
      balances.push({
        mint: info.mint,
        amount,
        decimals: info.tokenAmount.decimals
      });
    }
  }

  // Token-2022 program (nouveaux tokens SPL, ex : certains memecoins recents)
  try {
    const token2022Accounts = await conn.getParsedTokenAccountsByOwner(owner, {
      programId: new PublicKey("TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb")
    });
    for (const { account } of token2022Accounts.value) {
      const info = account.data.parsed.info;
      const amount = Number(info.tokenAmount.uiAmount ?? 0);
      if (amount > 0) {
        balances.push({ mint: info.mint, amount, decimals: info.tokenAmount.decimals });
      }
    }
  } catch {
    // Le programme Token-2022 peut etre indisponible sur certains RPC publics : on ignore silencieusement.
  }

  return balances;
}

/** Nombre de signatures (transactions) recentes pour un wallet — proxy gratuit d'activite on-chain. */
export async function getSolanaRecentTxCount(ownerAddress: string, limit = 1000): Promise<number> {
  const conn = getConnection();
  const owner = new PublicKey(ownerAddress);
  const signatures = await conn.getSignaturesForAddress(owner, { limit });
  return signatures.length;
}
