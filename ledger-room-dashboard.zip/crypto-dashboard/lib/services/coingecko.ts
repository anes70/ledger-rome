import { config } from "@/lib/config";
import { cached, fetchJson } from "@/lib/utils";
import type { ChainId, PriceHistoryPoint } from "@/lib/types";

const platformMap: Record<ChainId, string> = {
  solana: "solana",
  base: "base"
};

function authHeaders(): Record<string, string> {
  return config.keys.coingeckoPro ? { "x-cg-pro-api-key": config.keys.coingeckoPro } : {};
}

interface CgContractLookup {
  id: string;
  symbol: string;
  name: string;
  image?: { small?: string; large?: string };
  categories?: string[];
  genesis_date?: string | null;
  market_data?: {
    current_price?: { usd?: number };
    ath?: { usd?: number };
    atl?: { usd?: number };
    price_change_percentage_1h_in_currency?: { usd?: number };
    price_change_percentage_24h?: number;
    price_change_percentage_7d?: number;
    total_supply?: number | null;
    circulating_supply?: number | null;
    fully_diluted_valuation?: { usd?: number };
    market_cap?: { usd?: number };
  };
  community_data?: {
    twitter_followers?: number | null;
    reddit_subscribers?: number | null;
    reddit_accounts_active_48h?: number | null;
    telegram_channel_user_count?: number | null;
  };
  developer_data?: {
    stars?: number;
    forks?: number;
    commit_count_4_weeks?: number;
  };
  sentiment_votes_up_percentage?: number | null;
  sentiment_votes_down_percentage?: number | null;
  links?: {
    twitter_screen_name?: string;
    subreddit_url?: string;
    telegram_channel_identifier?: string;
    repos_url?: { github?: string[] };
    homepage?: string[];
  };
}

/**
 * Retrouve la fiche CoinGecko complete a partir d'une adresse de contrat.
 * Endpoint public gratuit (limite ~10-30 req/min sans cle) : couvre marche,
 * communaute (Twitter/Reddit/Telegram), sentiment et donnees developpeur (GitHub).
 */
export async function getCoinByContract(chain: ChainId, contractAddress: string): Promise<CgContractLookup | null> {
  const key = `cg-contract:${chain}:${contractAddress.toLowerCase()}`;
  return cached(key, config.cache.tokenDetailTtlMs, async () => {
    try {
      const platform = platformMap[chain];
      const url = `${config.endpoints.coingecko}/coins/${platform}/contract/${contractAddress}`;
      return await fetchJson<CgContractLookup>(url, { headers: authHeaders() });
    } catch {
      return null;
    }
  });
}

export async function getCoinById(coingeckoId: string): Promise<CgContractLookup | null> {
  const key = `cg-id:${coingeckoId}`;
  return cached(key, config.cache.tokenDetailTtlMs, async () => {
    try {
      const url = `${config.endpoints.coingecko}/coins/${coingeckoId}`;
      return await fetchJson<CgContractLookup>(url, { headers: authHeaders() });
    } catch {
      return null;
    }
  });
}

/** Historique de prix (7 jours, granularite horaire) pour calculer les indicateurs techniques. Gratuit, sans cle. */
export async function getMarketChart(coingeckoId: string, days = 7): Promise<PriceHistoryPoint[]> {
  const key = `cg-chart:${coingeckoId}:${days}`;
  return cached(key, config.cache.priceTtlMs, async () => {
    try {
      const url = `${config.endpoints.coingecko}/coins/${coingeckoId}/market_chart?vs_currency=usd&days=${days}`;
      const data = await fetchJson<{ prices: [number, number][] }>(url, { headers: authHeaders() });
      return data.prices.map(([timestamp, price]) => ({ timestamp, price }));
    } catch {
      return [];
    }
  });
}

/** Liste des categories/narratives (AI, DeFi, Gaming, Memecoin...) — utile pour la repartition par secteur. */
export function extractSector(categories: string[] | undefined): string[] {
  if (!categories || categories.length === 0) return ["Non classe"];
  return categories.slice(0, 3);
}
