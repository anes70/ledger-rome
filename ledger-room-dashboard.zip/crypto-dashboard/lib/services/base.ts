import { createPublicClient, http, formatEther, formatUnits, erc20Abi, isAddress } from "viem";
import { base as baseChain } from "viem/chains";
import { config, hasEvmIndexerKey } from "@/lib/config";
import { fetchJson } from "@/lib/utils";

const client = createPublicClient({
  chain: baseChain,
  transport: http(config.rpc.base)
});

export interface RawEvmBalance {
  contract: string; // "native" pour ETH
  amount: number;
  decimals: number;
  symbolHint?: string;
}

/** Solde ETH natif sur Base — 100% gratuit via RPC public. */
export async function getBaseNativeBalance(address: `0x${string}`): Promise<RawEvmBalance> {
  const wei = await client.getBalance({ address });
  return { contract: "native", amount: Number(formatEther(wei)), decimals: 18, symbolHint: "ETH" };
}

/** Nombre de transactions emises — proxy gratuit d'activite on-chain (via RPC public). */
export async function getBaseTxCount(address: `0x${string}`): Promise<number> {
  const count = await client.getTransactionCount({ address });
  return count;
}

/**
 * Liste des tokens ERC20 detenus.
 * - Sans cle : retourne une liste vide (le RPC seul ne permet pas d'enumerer les tokens
 *   d'une adresse — c'est une limitation technique universelle, pas propre a ce projet).
 * - Avec une cle Alchemy (gratuite jusqu'a un certain quota) : utilise `alchemy_getTokenBalances`.
 */
export async function getBaseErc20Balances(address: `0x${string}`): Promise<RawEvmBalance[]> {
  if (config.keys.alchemyBase) {
    try {
      const url = `https://base-mainnet.g.alchemy.com/v2/${config.keys.alchemyBase}`;
      const data = await fetchJson<{
        result: { tokenBalances: { contractAddress: string; tokenBalance: string }[] };
      }>(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          jsonrpc: "2.0",
          id: 1,
          method: "alchemy_getTokenBalances",
          params: [address, "erc20"]
        })
      });

      const nonZero = data.result.tokenBalances.filter(
        (t) => t.tokenBalance && BigInt(t.tokenBalance) > BigInt(0)
      );

      const balances: RawEvmBalance[] = [];
      for (const t of nonZero) {
        try {
          const contractAddress = t.contractAddress as `0x${string}`;
          const decimals = await client.readContract({
            address: contractAddress,
            abi: erc20Abi,
            functionName: "decimals"
          });
          balances.push({
            contract: contractAddress,
            amount: Number(formatUnits(BigInt(t.tokenBalance), decimals)),
            decimals
          });
        } catch {
          // Contrat non standard / illisible : on l'ignore plutot que de faire planter tout le portefeuille.
        }
      }
      return balances;
    } catch {
      return [];
    }
  }

  return [];
}

export function isEvmAddress(value: string): boolean {
  return isAddress(value);
}

export const evmIndexerAvailable = hasEvmIndexerKey;
