/**
 * Configuration centrale.
 *
 * Toutes les variables sont OPTIONNELLES : l'application fonctionne
 * entierement gratuitement sans aucune cle (RPC publics + APIs gratuites).
 * Ajouter une cle dans .env.local debloque simplement plus de profondeur
 * de donnees (ex : tokens ERC20 complets sur Base, indexeurs on-chain avances).
 */
export const config = {
  rpc: {
    solana: process.env.SOLANA_RPC_URL || "https://api.mainnet-beta.solana.com",
    base: process.env.BASE_RPC_URL || "https://mainnet.base.org"
  },
  keys: {
    // Indexeur EVM optionnel (Alchemy / Moralis / Covalent) pour lister
    // automatiquement TOUS les tokens ERC20 d'une adresse Base.
    alchemyBase: process.env.ALCHEMY_BASE_API_KEY || "",
    moralis: process.env.MORALIS_API_KEY || "",
    covalent: process.env.COVALENT_API_KEY || "",
    // Explorer Base (Basescan / Etherscan v2) optionnel, gratuit avec compte.
    basescan: process.env.BASESCAN_API_KEY || "",
    // Donnees marche additionnelles (facultatif, la version gratuite suffit).
    coingeckoPro: process.env.COINGECKO_PRO_API_KEY || "",
    birdeye: process.env.BIRDEYE_API_KEY || "",
    // Reseaux sociaux payants (non gratuits par defaut, desactives sans cle).
    twitterBearer: process.env.X_API_BEARER_TOKEN || "",
    telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || "",
    discordBotToken: process.env.DISCORD_BOT_TOKEN || ""
  },
  endpoints: {
    coingecko: "https://api.coingecko.com/api/v3",
    dexscreener: "https://api.dexscreener.com/latest/dex",
    defillama: "https://api.llama.fi",
    reddit: "https://www.reddit.com",
    github: "https://api.github.com"
  },
  cache: {
    // Duree de mise en cache en memoire (ms) pour eviter le rate-limit des APIs gratuites.
    priceTtlMs: 30_000,
    tokenDetailTtlMs: 60_000,
    socialTtlMs: 10 * 60_000
  }
} as const;

export function hasEvmIndexerKey(): boolean {
  return Boolean(config.keys.alchemyBase || config.keys.moralis || config.keys.covalent);
}
