export type ChainId = "solana" | "base";

export interface WalletAddresses {
  solana: string[];
  base: string[];
}

export interface PriceHistoryPoint {
  timestamp: number;
  price: number;
}

export interface Indicators {
  rsi14: number | null;
  sma20: number | null;
  sma50: number | null;
  ema20: number | null;
  ema50: number | null;
  macd: { macd: number; signal: number; histogram: number } | null;
  bollinger: { upper: number; middle: number; lower: number } | null;
  atr14: number | null;
  adx14: number | null;
  vwap: number | null;
  fibonacci: { level0: number; level236: number; level382: number; level5: number; level618: number; level786: number; level1: number } | null;
  trend: "haussier" | "baissier" | "neutre";
}

export type AiAction =
  | "RENFORCER"
  | "CONSERVER"
  | "VENDRE"
  | "ATTENDRE"
  | "EVITER"
  | "PRENDRE_PROFIT"
  | "COUPER_PERTE";

export interface AiAdvice {
  action: AiAction;
  confidence: number; // 0-100
  risk: number; // 0-100
  potential: number; // 0-100
  reinforcementScore: number; // 0-100
  horizon: "court terme" | "moyen terme" | "long terme";
  priceTarget: number | null;
  stopLoss: number | null;
  takeProfit: number | null;
  buyZone: { low: number; high: number } | null;
  sellZone: { low: number; high: number } | null;
  reasoning: string[];
}

export interface SocialData {
  coingeckoId: string | null;
  twitterFollowers: number | null;
  redditSubscribers: number | null;
  redditActiveUsers: number | null;
  telegramUsers: number | null;
  sentimentUpPct: number | null;
  sentimentDownPct: number | null;
  githubStars: number | null;
  githubForks: number | null;
  githubCommitsLast4Weeks: number | null;
  links: {
    twitter: string | null;
    reddit: string | null;
    telegram: string | null;
    github: string | null;
    homepage: string | null;
  };
  configured: {
    twitter: boolean;
    telegram: boolean;
    discord: boolean;
  };
}

export interface OnChainData {
  txCount30d: number | null;
  holderCount: number | null;
  liquidityUsd: number | null;
  tvlUsd: number | null;
  poolsCount: number | null;
  source: "free" | "indexer-required";
}

export interface TokenPosition {
  chain: ChainId;
  address: string; // mint / contract address, "native" for SOL/ETH
  symbol: string;
  name: string;
  logo: string | null;
  quantity: number;
  decimals: number;

  priceUsd: number | null;
  priceChange1h: number | null;
  priceChange24h: number | null;
  priceChange7d: number | null;
  ath: number | null;
  atl: number | null;

  valueUsd: number | null;

  avgBuyPrice: number | null; // user-entered cost basis
  pnlUsd: number | null;
  pnlPct: number | null;

  liquidityUsd: number | null;
  volume24hUsd: number | null;
  fdvUsd: number | null;
  marketCapUsd: number | null;
  supply: number | null;
  circulatingSupply: number | null;

  coingeckoId: string | null;
  sector: string[]; // narratives / categories (AI, DeFi, Gaming, Memecoin...)
  ageInDays: number | null;

  priceHistory7d: PriceHistoryPoint[];
  indicators: Indicators | null;

  isFavorite?: boolean;
  tags?: string[];
  notes?: string;
}

export interface PortfolioSnapshot {
  timestamp: number;
  totalValueUsd: number;
}

export interface AlertRule {
  id: string;
  tokenAddress: string;
  chain: ChainId;
  type: "prix_au_dessus" | "prix_en_dessous" | "rsi_survente" | "rsi_surachat" | "chute_liquidite" | "variation_24h";
  threshold: number;
  active: boolean;
  createdAt: number;
  triggeredAt: number | null;
}

export interface HistoryEntry {
  id: string;
  timestamp: number;
  type: "achat" | "vente" | "transfert" | "staking" | "lp" | "airdrop" | "recompense" | "decision_ia";
  tokenSymbol: string;
  chain: ChainId;
  quantity: number | null;
  priceUsd: number | null;
  note: string | null;
}
