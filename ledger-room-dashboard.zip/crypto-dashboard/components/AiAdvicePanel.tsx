import { Sparkles } from "lucide-react";
import clsx from "clsx";
import type { AiAdvice } from "@/lib/types";
import { formatUsd } from "@/lib/utils";

const actionLabels: Record<AiAdvice["action"], { label: string; tone: "up" | "down" | "amber" | "neutral" }> = {
  RENFORCER: { label: "Renforcer", tone: "up" },
  CONSERVER: { label: "Conserver", tone: "neutral" },
  VENDRE: { label: "Vendre", tone: "down" },
  ATTENDRE: { label: "Attendre", tone: "amber" },
  EVITER: { label: "Eviter", tone: "down" },
  PRENDRE_PROFIT: { label: "Prendre ses benefices", tone: "up" },
  COUPER_PERTE: { label: "Couper la perte", tone: "down" }
};

function ScoreBar({ label, value, colorClass }: { label: string; value: number; colorClass: string }) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-[11px] text-base-400">
        <span>{label}</span>
        <span className="mono-num">{value}%</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.06]">
        <div className={clsx("h-full rounded-full", colorClass)} style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

export function AiAdvicePanel({ advice, loading }: { advice: AiAdvice | null; loading: boolean }) {
  if (loading) {
    return <div className="animate-pulse rounded-xl border border-white/10 bg-white/[0.02] p-4 text-sm text-base-500">Analyse en cours…</div>;
  }
  if (!advice) {
    return <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4 text-sm text-base-500">Analyse indisponible.</div>;
  }

  const meta = actionLabels[advice.action];
  const toneClasses: Record<string, string> = {
    up: "border-signal-up/30 bg-signal-upDim text-signal-up",
    down: "border-signal-down/30 bg-signal-downDim text-signal-down",
    amber: "border-signal-amber/30 bg-signal-amberDim text-signal-amber",
    neutral: "border-white/10 bg-white/[0.03] text-base-200"
  };

  return (
    <div className="space-y-4">
      <div className={clsx("flex items-center justify-between rounded-xl border px-4 py-3", toneClasses[meta.tone])}>
        <div className="flex items-center gap-2">
          <Sparkles size={16} />
          <span className="font-display font-semibold">{meta.label}</span>
        </div>
        <span className="text-xs opacity-80">Horizon : {advice.horizon}</span>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <ScoreBar label="Confiance" value={advice.confidence} colorClass="bg-accent" />
        <ScoreBar label="Risque" value={advice.risk} colorClass="bg-signal-down" />
        <ScoreBar label="Potentiel" value={advice.potential} colorClass="bg-signal-up" />
        <ScoreBar label="Renforcement" value={advice.reinforcementScore} colorClass="bg-signal-amber" />
      </div>

      <div className="grid grid-cols-2 gap-3 text-xs">
        <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
          <p className="text-base-500">Stop loss conseille</p>
          <p className="mono-num mt-1 text-loss">{formatUsd(advice.stopLoss)}</p>
        </div>
        <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
          <p className="text-base-500">Take profit conseille</p>
          <p className="mono-num mt-1 text-gain">{formatUsd(advice.takeProfit)}</p>
        </div>
        {advice.buyZone && (
          <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
            <p className="text-base-500">Zone d&rsquo;accumulation</p>
            <p className="mono-num mt-1">{formatUsd(advice.buyZone.low)} – {formatUsd(advice.buyZone.high)}</p>
          </div>
        )}
        {advice.sellZone && (
          <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
            <p className="text-base-500">Zone de vente</p>
            <p className="mono-num mt-1">{formatUsd(advice.sellZone.low)} – {formatUsd(advice.sellZone.high)}</p>
          </div>
        )}
      </div>

      <div>
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-base-500">Pourquoi ?</p>
        <ul className="space-y-1.5">
          {advice.reasoning.map((r, i) => (
            <li key={i} className="flex gap-2 text-xs text-base-300">
              <span className="mt-1 h-1 w-1 flex-shrink-0 rounded-full bg-base-500" />
              {r}
            </li>
          ))}
        </ul>
      </div>

      <p className="text-[10px] text-base-600">
        Analyse generee automatiquement a partir de donnees publiques (prix, liquidite, indicateurs techniques).
        Ceci n&rsquo;est pas un conseil financier.
      </p>
    </div>
  );
}
