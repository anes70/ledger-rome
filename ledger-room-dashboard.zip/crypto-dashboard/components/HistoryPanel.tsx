"use client";

import { History } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import clsx from "clsx";
import { usePortfolioStore } from "@/store/usePortfolioStore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/Card";
import { formatUsd } from "@/lib/utils";
import type { HistoryEntry } from "@/lib/types";

const typeStyles: Record<HistoryEntry["type"], { label: string; tone: string }> = {
  achat: { label: "Achat / nouvelle position", tone: "text-gain" },
  vente: { label: "Vente / position fermee", tone: "text-loss" },
  transfert: { label: "Transfert", tone: "text-base-300" },
  staking: { label: "Staking", tone: "text-accent" },
  lp: { label: "Liquidity Pool", tone: "text-accent" },
  airdrop: { label: "Airdrop", tone: "text-signal-amber" },
  recompense: { label: "Recompense", tone: "text-signal-amber" },
  decision_ia: { label: "Decision IA", tone: "text-base-300" }
};

export function HistoryPanel() {
  const history = usePortfolioStore((s) => s.history);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center gap-2">
        <History size={16} className="text-base-400" />
        <CardTitle>Historique</CardTitle>
      </CardHeader>
      <CardContent>
        {history.length === 0 ? (
          <p className="py-4 text-center text-xs text-base-500">
            L&rsquo;historique se remplit automatiquement des que des changements sont detectes lors d&rsquo;une actualisation.
          </p>
        ) : (
          <ul className="max-h-80 space-y-2 overflow-y-auto">
            {history.map((h) => (
              <li key={h.id} className="flex items-start justify-between gap-3 rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2 text-xs">
                <div>
                  <p className={clsx("font-medium", typeStyles[h.type].tone)}>{typeStyles[h.type].label}</p>
                  <p className="mt-0.5 text-base-400">
                    {h.tokenSymbol} · {h.chain === "solana" ? "Solana" : "Base"}
                    {h.quantity !== null && ` · ${h.quantity.toLocaleString("fr-FR", { maximumFractionDigits: 4 })}`}
                    {h.priceUsd !== null && ` · ${formatUsd(h.priceUsd)}`}
                  </p>
                  {h.note && <p className="mt-0.5 text-base-500">{h.note}</p>}
                </div>
                <span className="mono-num flex-shrink-0 text-base-500">
                  {format(h.timestamp, "d MMM HH:mm", { locale: fr })}
                </span>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
