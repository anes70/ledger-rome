"use client";

import { useMemo } from "react";
import { usePortfolioStore } from "@/store/usePortfolioStore";
import { computePnlSince } from "@/lib/pnl";
import { formatUsd, formatPct } from "@/lib/utils";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/Card";
import clsx from "clsx";

function PnlLine({ label, result }: { label: string; result: ReturnType<typeof computePnlSince> }) {
  if (!result) {
    return (
      <div className="flex items-center justify-between text-xs">
        <span className="text-base-400">{label}</span>
        <span className="text-base-500">Historique insuffisant</span>
      </div>
    );
  }
  const positive = result.absolute >= 0;
  return (
    <div className="flex items-center justify-between text-xs">
      <span className="text-base-400">{label}</span>
      <span className={clsx("mono-num font-medium", positive ? "text-gain" : "text-loss")}>
        {formatUsd(result.absolute, { compact: true })} ({formatPct(result.pct)})
      </span>
    </div>
  );
}

export function PortfolioSummaryCards() {
  const tokens = usePortfolioStore((s) => s.tokens);
  const snapshots = usePortfolioStore((s) => s.snapshots);

  const totalValue = useMemo(() => tokens.reduce((sum, t) => sum + (t.valueUsd ?? 0), 0), [tokens]);
  const totalCost = useMemo(
    () =>
      tokens.reduce((sum, t) => (t.avgBuyPrice !== null ? sum + t.avgBuyPrice * t.quantity : sum), 0),
    [tokens]
  );
  const hasCostBasis = tokens.some((t) => t.avgBuyPrice !== null);
  const totalPnl = hasCostBasis ? totalValue - totalCost : null;
  const totalPnlPct = hasCostBasis && totalCost > 0 ? (totalPnl! / totalCost) * 100 : null;

  const dailyPnl = computePnlSince(snapshots, totalValue, 24 * 60 * 60 * 1000);
  const weeklyPnl = computePnlSince(snapshots, totalValue, 7 * 24 * 60 * 60 * 1000);
  const monthlyPnl = computePnlSince(snapshots, totalValue, 30 * 24 * 60 * 60 * 1000);

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader>
          <CardTitle>Valeur totale</CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <p className="mono-num font-display text-3xl font-semibold">{formatUsd(totalValue)}</p>
          <p className="mt-1 text-xs text-base-400">{tokens.length} position{tokens.length > 1 ? "s" : ""}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>PNL total</CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          {totalPnl !== null ? (
            <>
              <p className={clsx("mono-num font-display text-3xl font-semibold", totalPnl >= 0 ? "text-gain" : "text-loss")}>
                {formatUsd(totalPnl, { compact: true })}
              </p>
              <p className={clsx("mt-1 text-xs font-medium", totalPnl >= 0 ? "text-gain" : "text-loss")}>
                {formatPct(totalPnlPct)}
              </p>
            </>
          ) : (
            <>
              <p className="font-display text-lg text-base-400">Renseignez un prix d&rsquo;achat</p>
              <p className="mt-1 text-xs text-base-500">pour activer le calcul de PNL</p>
            </>
          )}
        </CardContent>
      </Card>

      <Card className="sm:col-span-2 lg:col-span-2">
        <CardHeader>
          <CardTitle>Performance dans le temps</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2.5 pt-2">
          <PnlLine label="24 heures" result={dailyPnl} />
          <PnlLine label="7 jours" result={weeklyPnl} />
          <PnlLine label="30 jours" result={monthlyPnl} />
        </CardContent>
      </Card>
    </div>
  );
}
