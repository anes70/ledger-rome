"use client";

import { RefreshCw } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";
import { usePortfolioStore } from "@/store/usePortfolioStore";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

export function Header() {
  const loading = usePortfolioStore((s) => s.loading);
  const lastUpdated = usePortfolioStore((s) => s.lastUpdated);
  const refresh = usePortfolioStore((s) => s.refresh);
  const hasAddresses = usePortfolioStore((s) => s.addresses.solana.length + s.addresses.base.length > 0);

  return (
    <header className="sticky top-0 z-30 border-b border-white/[0.06] bg-base-950/70 backdrop-blur-xl">
      <div className="mx-auto flex max-w-[1400px] items-center justify-between gap-4 px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent-dim">
            <span className="h-2 w-2 rounded-full bg-signal-up animate-pulse-dot" />
          </div>
          <div>
            <h1 className="font-display text-base font-semibold leading-none tracking-tight">Ledger Room</h1>
            <p className="mono-num text-[11px] text-base-400 leading-none mt-1">
              Base · Solana — donnees en direct
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {lastUpdated && (
            <span className="hidden sm:block mono-num text-xs text-base-400">
              Maj {formatDistanceToNow(lastUpdated, { addSuffix: true, locale: fr })}
            </span>
          )}
          <button
            onClick={() => refresh()}
            disabled={loading || !hasAddresses}
            className="focus-ring flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-sm font-medium text-base-200 transition hover:bg-white/[0.08] disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
            Actualiser
          </button>
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
