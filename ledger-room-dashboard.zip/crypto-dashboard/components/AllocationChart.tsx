"use client";

import { useMemo, useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { usePortfolioStore } from "@/store/usePortfolioStore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/Card";
import { formatUsd } from "@/lib/utils";
import clsx from "clsx";

const COLORS = ["#5B8CFF", "#1FE0A6", "#FFB454", "#FF5C72", "#B48CFF", "#4FD1FF", "#F472B6", "#A3E635"];

type Mode = "token" | "chaine" | "secteur";

export function AllocationChart() {
  const tokens = usePortfolioStore((s) => s.tokens);
  const [mode, setMode] = useState<Mode>("token");

  const data = useMemo(() => {
    if (tokens.length === 0) return [];
    if (mode === "token") {
      const sorted = [...tokens].sort((a, b) => (b.valueUsd ?? 0) - (a.valueUsd ?? 0));
      const top = sorted.slice(0, 7);
      const rest = sorted.slice(7);
      const restValue = rest.reduce((sum, t) => sum + (t.valueUsd ?? 0), 0);
      const result = top.map((t) => ({ name: t.symbol, value: t.valueUsd ?? 0 }));
      if (restValue > 0) result.push({ name: "Autres", value: restValue });
      return result;
    }
    if (mode === "chaine") {
      const map = new Map<string, number>();
      for (const t of tokens) {
        const label = t.chain === "solana" ? "Solana" : "Base";
        map.set(label, (map.get(label) ?? 0) + (t.valueUsd ?? 0));
      }
      return Array.from(map.entries()).map(([name, value]) => ({ name, value }));
    }
    // secteur / narrative
    const map = new Map<string, number>();
    for (const t of tokens) {
      const sector = t.sector[0] || "Non classe";
      map.set(sector, (map.get(sector) ?? 0) + (t.valueUsd ?? 0));
    }
    return Array.from(map.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([name, value]) => ({ name, value }));
  }, [tokens, mode]);

  const total = data.reduce((sum, d) => sum + d.value, 0);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Repartition</CardTitle>
        <div className="flex gap-1 rounded-full border border-white/10 p-0.5">
          {(["token", "chaine", "secteur"] as Mode[]).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={clsx(
                "rounded-full px-2.5 py-1 text-[11px] font-medium capitalize transition",
                mode === m ? "bg-accent text-white" : "text-base-400 hover:text-base-200"
              )}
            >
              {m}
            </button>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        {data.length === 0 ? (
          <p className="py-10 text-center text-sm text-base-500">Aucune position a afficher.</p>
        ) : (
          <div className="flex items-center gap-4">
            <div className="h-[180px] w-[180px] flex-shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={data} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2}>
                    {data.map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) => formatUsd(value)}
                    contentStyle={{
                      background: "#10141B",
                      border: "1px solid rgba(255,255,255,0.08)",
                      borderRadius: 8,
                      fontSize: 12
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-1.5 overflow-hidden">
              {data.map((d, i) => (
                <div key={d.name} className="flex items-center justify-between gap-2 text-xs">
                  <span className="flex items-center gap-2 truncate">
                    <span className="h-2 w-2 flex-shrink-0 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                    <span className="truncate text-base-300">{d.name}</span>
                  </span>
                  <span className="mono-num flex-shrink-0 text-base-400">
                    {total > 0 ? ((d.value / total) * 100).toFixed(1) : "0"}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
