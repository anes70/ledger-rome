import clsx from "clsx";
import type { HTMLAttributes } from "react";

type Tone = "neutral" | "up" | "down" | "amber" | "accent";

const toneClasses: Record<Tone, string> = {
  neutral: "bg-base-700/60 text-base-200 border-base-600",
  up: "bg-signal-upDim text-signal-up border-signal-up/30",
  down: "bg-signal-downDim text-signal-down border-signal-down/30",
  amber: "bg-signal-amberDim text-signal-amber border-signal-amber/30",
  accent: "bg-accent-dim text-accent border-accent/30"
};

export function Badge({
  tone = "neutral",
  className,
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: Tone }) {
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-medium",
        toneClasses[tone],
        className
      )}
      {...props}
    />
  );
}
