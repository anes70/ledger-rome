"use client";

import { useState } from "react";
import { Wallet, Plus, X } from "lucide-react";
import { usePortfolioStore } from "@/store/usePortfolioStore";
import { truncateAddress } from "@/lib/utils";

declare global {
  interface Window {
    solana?: { isPhantom?: boolean; connect: () => Promise<{ publicKey: { toString(): string } }> };
    backpack?: { connect: () => Promise<{ publicKey: { toString(): string } }> };
    ethereum?: { request: (args: { method: string; params?: unknown[] }) => Promise<unknown> };
  }
}

export function WalletInput() {
  const addresses = usePortfolioStore((s) => s.addresses);
  const setAddresses = usePortfolioStore((s) => s.setAddresses);
  const refresh = usePortfolioStore((s) => s.refresh);

  const [solInput, setSolInput] = useState("");
  const [baseInput, setBaseInput] = useState("");
  const [connectError, setConnectError] = useState<string | null>(null);

  function addSolana() {
    const trimmed = solInput.trim();
    if (!trimmed || addresses.solana.includes(trimmed)) return;
    setAddresses({ ...addresses, solana: [...addresses.solana, trimmed] });
    setSolInput("");
  }

  function addBase() {
    const trimmed = baseInput.trim();
    if (!trimmed || addresses.base.includes(trimmed)) return;
    setAddresses({ ...addresses, base: [...addresses.base, trimmed] });
    setBaseInput("");
  }

  function removeSolana(addr: string) {
    setAddresses({ ...addresses, solana: addresses.solana.filter((a) => a !== addr) });
  }
  function removeBase(addr: string) {
    setAddresses({ ...addresses, base: addresses.base.filter((a) => a !== addr) });
  }

  async function connectPhantom() {
    setConnectError(null);
    try {
      if (!window.solana?.isPhantom) {
        setConnectError("Phantom n'est pas installe dans ce navigateur.");
        return;
      }
      const resp = await window.solana.connect();
      const pub = resp.publicKey.toString();
      if (!addresses.solana.includes(pub)) {
        setAddresses({ ...addresses, solana: [...addresses.solana, pub] });
      }
    } catch {
      setConnectError("Connexion Phantom annulee ou impossible.");
    }
  }

  async function connectBackpack() {
    setConnectError(null);
    try {
      if (!window.backpack) {
        setConnectError("Backpack n'est pas installe dans ce navigateur.");
        return;
      }
      const resp = await window.backpack.connect();
      const pub = resp.publicKey.toString();
      if (!addresses.solana.includes(pub)) {
        setAddresses({ ...addresses, solana: [...addresses.solana, pub] });
      }
    } catch {
      setConnectError("Connexion Backpack annulee ou impossible.");
    }
  }

  async function connectEvm() {
    setConnectError(null);
    try {
      if (!window.ethereum) {
        setConnectError("Aucun wallet EVM (MetaMask / Coinbase Wallet) detecte.");
        return;
      }
      const accounts = (await window.ethereum.request({ method: "eth_requestAccounts" })) as string[];
      const addr = accounts[0];
      if (addr && !addresses.base.includes(addr)) {
        setAddresses({ ...addresses, base: [...addresses.base, addr] });
      }
    } catch {
      setConnectError("Connexion du wallet EVM annulee ou impossible.");
    }
  }

  return (
    <div className="mx-auto max-w-2xl animate-rise">
      <div className="mb-8 text-center">
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-accent-dim">
          <Wallet size={20} className="text-accent" />
        </div>
        <h2 className="font-display text-2xl font-semibold">Connectez votre portefeuille</h2>
        <p className="mt-2 text-sm text-base-400">
          Adresse publique uniquement — aucune cle privee n&rsquo;est jamais demandee.
        </p>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <button onClick={connectPhantom} className="focus-ring rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3 text-xs font-medium text-base-200 transition hover:bg-white/[0.08]">
          Phantom
        </button>
        <button onClick={connectBackpack} className="focus-ring rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3 text-xs font-medium text-base-200 transition hover:bg-white/[0.08]">
          Backpack
        </button>
        <button onClick={connectEvm} className="focus-ring rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3 text-xs font-medium text-base-200 transition hover:bg-white/[0.08]">
          MetaMask
        </button>
        <button onClick={connectEvm} className="focus-ring rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3 text-xs font-medium text-base-200 transition hover:bg-white/[0.08]">
          Coinbase Wallet
        </button>
      </div>

      {connectError && <p className="mb-4 text-center text-xs text-signal-down">{connectError}</p>}

      <div className="glass rounded-2xl p-5 space-y-5">
        <div>
          <label className="mb-2 block text-xs font-medium uppercase tracking-wide text-base-400">
            Adresse Solana
          </label>
          <div className="flex gap-2">
            <input
              value={solInput}
              onChange={(e) => setSolInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addSolana()}
              placeholder="ex : 7xKX...9pQ2"
              className="focus-ring mono-num flex-1 rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2 text-sm placeholder:text-base-500"
            />
            <button onClick={addSolana} className="focus-ring rounded-lg bg-accent px-3 text-white transition hover:opacity-90">
              <Plus size={16} />
            </button>
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            {addresses.solana.map((a) => (
              <span key={a} className="mono-num flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-xs">
                {truncateAddress(a)}
                <button onClick={() => removeSolana(a)} aria-label="Retirer">
                  <X size={12} className="text-base-400 hover:text-signal-down" />
                </button>
              </span>
            ))}
          </div>
        </div>

        <div>
          <label className="mb-2 block text-xs font-medium uppercase tracking-wide text-base-400">
            Adresse Base (EVM)
          </label>
          <div className="flex gap-2">
            <input
              value={baseInput}
              onChange={(e) => setBaseInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addBase()}
              placeholder="ex : 0xAbC1...9F3d"
              className="focus-ring mono-num flex-1 rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2 text-sm placeholder:text-base-500"
            />
            <button onClick={addBase} className="focus-ring rounded-lg bg-accent px-3 text-white transition hover:opacity-90">
              <Plus size={16} />
            </button>
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            {addresses.base.map((a) => (
              <span key={a} className="mono-num flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-xs">
                {truncateAddress(a)}
                <button onClick={() => removeBase(a)} aria-label="Retirer">
                  <X size={12} className="text-base-400 hover:text-signal-down" />
                </button>
              </span>
            ))}
          </div>
        </div>

        <button
          onClick={() => refresh()}
          disabled={addresses.solana.length === 0 && addresses.base.length === 0}
          className="focus-ring w-full rounded-lg bg-accent py-2.5 text-sm font-semibold text-white transition hover:opacity-90 disabled:opacity-30 disabled:cursor-not-allowed"
        >
          Charger le portefeuille
        </button>
      </div>
    </div>
  );
}
