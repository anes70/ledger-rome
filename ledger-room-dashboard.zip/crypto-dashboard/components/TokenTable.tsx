"use client";

import { useMemo, useState } from "react";
import Image from "next/image";
import { Search, Star, ArrowUpDown } from "lucide-react";
import clsx from "clsx";
import { usePortfolioStore } from "@/store/usePortfolioStore";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { formatUsd, formatPct, formatCompactNumber } from "@/lib/utils";
import type { ChainId, TokenPosition } from "@/lib/types";

type SortKey = "valueUsd" | "priceChange24h" | "pnlPct" | "liquidityUsd" | "marketCapUsd";

const columns: { key: SortKey; label: string }[] = [
  { key: "valueUsd", label: "Valeur" },
  { key: "priceChange24h", label: "24h" },
  { key: "pnlPct", label: "PNL" },
  { key: "liquidityUsd", label: "Liquidite" },
  { key: "marketCapUsd", label: "Market Cap" }
];

export function TokenTable({ onSelect }: { onSelect: (token: TokenPosition) => void }) {
  const tokens = usePortfolioStore((s) => s.tokens);
  const toggleFavorite = usePortfolioStore((s) => s.toggleFavorite);
  const loading = usePortfolioStore((s) => s.loading);

  const [query, setQuery] = useState("");
  const [chainFilter, setChainFilter] = useState<ChainId | "all">("all");
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [sortKey, setSortKey] = useState<SortKey>("valueUsd");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");

  const filtered = useMemo(() => {
    let result = [...tokens];
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      result = result.filter(
        (t) => t.symbol.toLowerCase().includes(q) || t.name.toLowerCase().includes(q)
      );
    }
    if (chainFilter !== "all") result = result.filter((t) => t.chain === chainFilter);
    if (favoritesOnly) result = result.filter((t) => t.isFavorite);

    result.sort((a, b) => {
      const av = a[sortKey] ?? -Infinity;
      const bv = b[sortKey] ?? -Infinity;
      return sortDir === "desc" ? bv - av : av - bv;
    });
    return result;
  }, [tokens, query, chainFilter, favoritesOnly, sortKey, sortDir]);

  function onSort(key: SortKey) {
    if (key === sortKey) setSortDir(sortDir === "desc" ? "asc" : "desc");
    else {
      setSortKey(key);
      setSortDir("desc");
    }
  }

  return (
    <Card>
      <div className="flex flex-col gap-3 border-b border-white/[0.06] p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 sm:max-w-xs">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-base-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Rechercher un token…"
            className="focus-ring w-full rounded-lg border border-white/10 bg-white/[0.02] py-2 pl-9 pr-3 text-sm placeholder:text-base-500"
          />
        </div>
        <div className="flex items-center gap-2">
          <div className="flex gap-1 rounded-full border border-white/10 p-0.5">
            {(["all", "solana", "base"] as const).map((c) => (
              <button
                key={c}
                onClick={() => setChainFilter(c)}
                className={clsx(
                  "rounded-full px-2.5 py-1 text-[11px] font-medium capitalize transition",
                  chainFilter === c ? "bg-accent text-white" : "text-base-400 hover:text-base-200"
                )}
              >
                {c === "all" ? "Tout" : c}
              </button>
            ))}
          </div>
          <button
            onClick={() => setFavoritesOnly(!favoritesOnly)}
            className={clsx(
              "focus-ring flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-medium transition",
              favoritesOnly ? "border-signal-amber/40 bg-signal-amberDim text-signal-amber" : "border-white/10 text-base-400 hover:text-base-200"
            )}
          >
            <Star size={12} fill={favoritesOnly ? "currentColor" : "none"} />
            Favoris
          </button>
        </div>
      </div>

      {loading && tokens.length === 0 ? (
        <div className="p-10 text-center text-sm text-base-500">Chargement du portefeuille…</div>
      ) : filtered.length === 0 ? (
        <div className="p-10 text-center text-sm text-base-500">Aucun token ne correspond.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/[0.06] text-left text-[11px] uppercase tracking-wide text-base-500">
                <th className="px-4 py-3 font-medium">Token</th>
                {columns.map((c) => (
                  <th key={c.key} className="px-4 py-3 font-medium">
                    <button onClick={() => onSort(c.key)} className="flex items-center gap-1 hover:text-base-200">
                      {c.label}
                      <ArrowUpDown size={10} className={sortKey === c.key ? "text-accent" : "opacity-40"} />
                    </button>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((t) => (
                <tr
                  key={`${t.chain}:${t.address}`}
                  onClick={() => onSelect(t)}
                  className="cursor-pointer border-b border-white/[0.04] transition hover:bg-white/[0.03]"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(t.chain, t.address);
                        }}
                        aria-label="Favori"
                      >
                        <Star size={13} className={t.isFavorite ? "text-signal-amber" : "text-base-600"} fill={t.isFavorite ? "currentColor" : "none"} />
                      </button>
                      <div className="relative h-7 w-7 flex-shrink-0 overflow-hidden rounded-full bg-base-700">
                        {t.logo && (
                          <Image src={t.logo} alt={t.symbol} fill sizes="28px" className="object-cover" unoptimized />
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-medium text-base-100">{t.symbol}</span>
                          <Badge tone={t.chain === "solana" ? "accent" : "neutral"} className="text-[9px] px-1.5 py-0">
                            {t.chain === "solana" ? "SOL" : "BASE"}
                          </Badge>
                        </div>
                        <p className="truncate text-xs text-base-500">{t.name}</p>
                      </div>
                    </div>
                  </td>
                  <td className="mono-num px-4 py-3">
                    <div>{formatUsd(t.valueUsd)}</div>
                    <div className="text-xs text-base-500">
                      {t.quantity.toLocaleString("fr-FR", { maximumFractionDigits: 4 })} · {formatUsd(t.priceUsd)}
                    </div>
                  </td>
                  <td className={clsx("mono-num px-4 py-3", (t.priceChange24h ?? 0) >= 0 ? "text-gain" : "text-loss")}>
                    {formatPct(t.priceChange24h)}
                  </td>
                  <td className={clsx("mono-num px-4 py-3", t.pnlPct === null ? "text-base-500" : t.pnlPct >= 0 ? "text-gain" : "text-loss")}>
                    {formatPct(t.pnlPct)}
                  </td>
                  <td className="mono-num px-4 py-3 text-base-300">{formatUsd(t.liquidityUsd, { compact: true })}</td>
                  <td className="mono-num px-4 py-3 text-base-300">{formatCompactNumber(t.marketCapUsd)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}
