"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { X, ExternalLink, Github, MessageCircle } from "lucide-react";
import { LineChart, Line, ResponsiveContainer, YAxis } from "recharts";
import { AnimatePresence, motion } from "framer-motion";
import type { AiAdvice, Indicators, PriceHistoryPoint, SocialData, TokenPosition } from "@/lib/types";
import { formatUsd, formatPct, formatCompactNumber } from "@/lib/utils";
import { usePortfolioStore } from "@/store/usePortfolioStore";
import { AiAdvicePanel } from "@/components/AiAdvicePanel";
import { Badge } from "@/components/ui/Badge";
import clsx from "clsx";

function StatBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
      <p className="text-[11px] text-base-500">{label}</p>
      <p className="mono-num mt-1 text-sm text-base-100">{value}</p>
    </div>
  );
}

export function TokenDetailDrawer({ token, onClose }: { token: TokenPosition | null; onClose: () => void }) {
  const setCostBasis = usePortfolioStore((s) => s.setCostBasis);
  const setTags = usePortfolioStore((s) => s.setTags);
  const setNote = usePortfolioStore((s) => s.setNote);

  const [priceHistory, setPriceHistory] = useState<PriceHistoryPoint[]>([]);
  const [indicators, setIndicators] = useState<Indicators | null>(null);
  const [advice, setAdvice] = useState<AiAdvice | null>(null);
  const [social, setSocial] = useState<SocialData | null>(null);
  const [loadingAnalysis, setLoadingAnalysis] = useState(false);
  const [costInput, setCostInput] = useState("");
  const [noteInput, setNoteInput] = useState("");
  const [tagInput, setTagInput] = useState("");

  useEffect(() => {
    if (!token) return;
    setCostInput(token.avgBuyPrice?.toString() ?? "");
    setNoteInput(token.notes ?? "");
    setPriceHistory([]);
    setIndicators(null);
    setAdvice(null);
    setSocial(null);
    setLoadingAnalysis(true);

    const controller = new AbortController();

    Promise.all([
      fetch("/api/token", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          coingeckoId: token.coingeckoId,
          chain: token.chain,
          priceUsd: token.priceUsd,
          priceChange24h: token.priceChange24h,
          priceChange7d: token.priceChange7d,
          liquidityUsd: token.liquidityUsd,
          volume24hUsd: token.volume24hUsd,
          marketCapUsd: token.marketCapUsd,
          ageInDays: token.ageInDays,
          avgBuyPrice: token.avgBuyPrice,
          pnlPct: token.pnlPct
        })
      })
        .then((r) => r.json())
        .then((data) => {
          setPriceHistory(data.priceHistory7d || []);
          setIndicators(data.indicators || null);
          setAdvice(data.advice || null);
        })
        .catch(() => {}),
      fetch("/api/social", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({ chain: token.chain, address: token.address, coingeckoId: token.coingeckoId })
      })
        .then((r) => r.json())
        .then((data) => setSocial(data.social || null))
        .catch(() => {})
    ]).finally(() => setLoadingAnalysis(false));

    return () => controller.abort();
  }, [token]);

  if (!token) return null;

  const chartData = priceHistory.map((p) => ({ time: p.timestamp, price: p.price }));
  const currentTags = token.tags || [];

  return (
    <AnimatePresence>
      {token && (
        <>
          <motion.div
            className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.aside
            className="fixed right-0 top-0 z-50 h-full w-full max-w-lg overflow-y-auto border-l border-white/10 bg-base-900 shadow-2xl"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "tween", duration: 0.25 }}
          >
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-white/10 bg-base-900/95 px-5 py-4 backdrop-blur">
              <div className="flex items-center gap-3">
                <div className="relative h-9 w-9 overflow-hidden rounded-full bg-base-700">
                  {token.logo && <Image src={token.logo} alt={token.symbol} fill sizes="36px" className="object-cover" unoptimized />}
                </div>
                <div>
                  <p className="font-display font-semibold">{token.symbol}</p>
                  <p className="text-xs text-base-500">{token.name}</p>
                </div>
              </div>
              <button onClick={onClose} className="focus-ring rounded-full p-1.5 text-base-400 hover:bg-white/5 hover:text-base-100">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-6 p-5">
              <div>
                <p className="mono-num font-display text-3xl font-semibold">{formatUsd(token.priceUsd)}</p>
                <div className="mt-1 flex gap-3 text-xs">
                  <span className={clsx(token.priceChange1h && token.priceChange1h >= 0 ? "text-gain" : "text-loss")}>
                    1h {formatPct(token.priceChange1h)}
                  </span>
                  <span className={clsx(token.priceChange24h && token.priceChange24h >= 0 ? "text-gain" : "text-loss")}>
                    24h {formatPct(token.priceChange24h)}
                  </span>
                  <span className={clsx(token.priceChange7d && token.priceChange7d >= 0 ? "text-gain" : "text-loss")}>
                    7j {formatPct(token.priceChange7d)}
                  </span>
                </div>
              </div>

              {chartData.length > 1 && (
                <div className="h-[80px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                      <YAxis hide domain={["dataMin", "dataMax"]} />
                      <Line type="monotone" dataKey="price" stroke="#5B8CFF" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <StatBox label="Valeur detenue" value={formatUsd(token.valueUsd)} />
                <StatBox label="Quantite" value={token.quantity.toLocaleString("fr-FR", { maximumFractionDigits: 6 })} />
                <StatBox label="Liquidite" value={formatUsd(token.liquidityUsd, { compact: true })} />
                <StatBox label="Volume 24h" value={formatUsd(token.volume24hUsd, { compact: true })} />
                <StatBox label="FDV" value={formatUsd(token.fdvUsd, { compact: true })} />
                <StatBox label="Market Cap" value={formatUsd(token.marketCapUsd, { compact: true })} />
                <StatBox label="ATH" value={formatUsd(token.ath)} />
                <StatBox label="ATL" value={formatUsd(token.atl)} />
                <StatBox label="Supply totale" value={formatCompactNumber(token.supply)} />
                <StatBox label="Supply circulante" value={formatCompactNumber(token.circulatingSupply)} />
                <StatBox label="Age du projet" value={token.ageInDays !== null ? `${token.ageInDays} j` : "—"} />
                <StatBox label="Chaine" value={token.chain === "solana" ? "Solana" : "Base"} />
              </div>

              <div className="flex flex-wrap gap-1.5">
                {token.sector.map((s) => (
                  <Badge key={s} tone="accent">{s}</Badge>
                ))}
              </div>

              <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
                <p className="mb-3 text-xs font-medium uppercase tracking-wide text-base-500">Prix moyen d&rsquo;achat (PNL)</p>
                <div className="flex gap-2">
                  <input
                    value={costInput}
                    onChange={(e) => setCostInput(e.target.value)}
                    type="number"
                    step="any"
                    placeholder="Prix moyen en USD"
                    className="focus-ring mono-num flex-1 rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2 text-sm"
                  />
                  <button
                    onClick={() => {
                      const val = parseFloat(costInput);
                      if (!Number.isNaN(val) && val > 0) setCostBasis(token.chain, token.address, val);
                    }}
                    className="focus-ring rounded-lg bg-accent px-4 text-sm font-medium text-white hover:opacity-90"
                  >
                    Enregistrer
                  </button>
                </div>
                {token.pnlUsd !== null && (
                  <p className={clsx("mt-2 text-sm font-medium", token.pnlUsd >= 0 ? "text-gain" : "text-loss")}>
                    {formatUsd(token.pnlUsd, { compact: true })} ({formatPct(token.pnlPct)})
                  </p>
                )}
              </div>

              <section>
                <h4 className="mb-3 font-display text-sm font-semibold">Analyse technique</h4>
                {loadingAnalysis ? (
                  <p className="text-sm text-base-500">Calcul des indicateurs…</p>
                ) : indicators ? (
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                    <StatBox label="RSI 14" value={indicators.rsi14?.toFixed(1) ?? "—"} />
                    <StatBox label="SMA 20" value={formatUsd(indicators.sma20)} />
                    <StatBox label="EMA 20" value={formatUsd(indicators.ema20)} />
                    <StatBox label="MACD" value={indicators.macd ? indicators.macd.histogram.toFixed(4) : "—"} />
                    <StatBox label="ATR 14" value={indicators.atr14?.toFixed(4) ?? "—"} />
                    <StatBox label="ADX 14" value={indicators.adx14?.toFixed(1) ?? "—"} />
                    <StatBox label="Bollinger sup." value={formatUsd(indicators.bollinger?.upper ?? null)} />
                    <StatBox label="Bollinger inf." value={formatUsd(indicators.bollinger?.lower ?? null)} />
                    <StatBox label="Tendance" value={indicators.trend} />
                  </div>
                ) : (
                  <p className="text-sm text-base-500">Historique de prix insuffisant pour ce token.</p>
                )}
              </section>

              <section>
                <h4 className="mb-3 font-display text-sm font-semibold">Intelligence artificielle</h4>
                <AiAdvicePanel advice={advice} loading={loadingAnalysis} />
              </section>

              <section>
                <h4 className="mb-3 font-display text-sm font-semibold">Analyse sociale</h4>
                {loadingAnalysis ? (
                  <p className="text-sm text-base-500">Chargement…</p>
                ) : social ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <StatBox label="Abonnes X (Twitter)" value={formatCompactNumber(social.twitterFollowers)} />
                      <StatBox label="Abonnes Reddit" value={formatCompactNumber(social.redditSubscribers)} />
                      <StatBox label="Membres Telegram" value={formatCompactNumber(social.telegramUsers)} />
                      <StatBox label="GitHub ★" value={formatCompactNumber(social.githubStars)} />
                      <StatBox label="Sentiment positif" value={social.sentimentUpPct !== null ? `${social.sentimentUpPct.toFixed(0)}%` : "—"} />
                      <StatBox label="Commits (4 sem.)" value={formatCompactNumber(social.githubCommitsLast4Weeks)} />
                    </div>
                    <div className="flex flex-wrap gap-3 text-xs">
                      {social.links.twitter && (
                        <a href={social.links.twitter} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-accent hover:underline">
                          <ExternalLink size={12} /> X / Twitter
                        </a>
                      )}
                      {social.links.reddit && (
                        <a href={social.links.reddit} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-accent hover:underline">
                          <MessageCircle size={12} /> Reddit
                        </a>
                      )}
                      {social.links.github && (
                        <a href={social.links.github} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-accent hover:underline">
                          <Github size={12} /> GitHub
                        </a>
                      )}
                    </div>
                    {(!social.configured.twitter || !social.configured.telegram || !social.configured.discord) && (
                      <p className="text-[10px] text-base-600">
                        Donnees Telegram temps reel / Discord / activite X detaillee necessitent des cles API
                        payantes non configurees. Ajoutez-les dans .env.local pour les activer (voir README).
                      </p>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-base-500">Aucune donnee sociale trouvee pour ce token.</p>
                )}
              </section>

              <section>
                <h4 className="mb-3 font-display text-sm font-semibold">Notes &amp; tags personnels</h4>
                <div className="space-y-3">
                  <textarea
                    value={noteInput}
                    onChange={(e) => setNoteInput(e.target.value)}
                    onBlur={() => setNote(token.chain, token.address, noteInput)}
                    placeholder="Votre these d'investissement, rappels, etc."
                    className="focus-ring w-full rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2 text-sm placeholder:text-base-500"
                    rows={3}
                  />
                  <div className="flex flex-wrap gap-1.5">
                    {currentTags.map((tag) => (
                      <Badge key={tag} tone="neutral" className="cursor-pointer" onClick={() => setTags(token.chain, token.address, currentTags.filter((t) => t !== tag))}>
                        {tag} ✕
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <input
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && tagInput.trim()) {
                          setTags(token.chain, token.address, [...currentTags, tagInput.trim()]);
                          setTagInput("");
                        }
                      }}
                      placeholder="Ajouter un tag puis Entree"
                      className="focus-ring flex-1 rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2 text-sm placeholder:text-base-500"
                    />
                  </div>
                </div>
              </section>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
