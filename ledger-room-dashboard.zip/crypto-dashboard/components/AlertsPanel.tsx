"use client";

import { useState } from "react";
import { Bell, Trash2, BellOff, BellRing } from "lucide-react";
import clsx from "clsx";
import { usePortfolioStore } from "@/store/usePortfolioStore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/Card";
import type { AlertRule } from "@/lib/types";

const alertTypeLabels: Record<AlertRule["type"], string> = {
  prix_au_dessus: "Prix au-dessus de",
  prix_en_dessous: "Prix en dessous de",
  rsi_survente: "RSI en survente sous",
  rsi_surachat: "RSI en surachat au-dessus de",
  chute_liquidite: "Liquidite sous",
  variation_24h: "Variation 24h superieure a"
};

export function AlertsPanel() {
  const tokens = usePortfolioStore((s) => s.tokens);
  const alerts = usePortfolioStore((s) => s.alerts);
  const addAlert = usePortfolioStore((s) => s.addAlert);
  const removeAlert = usePortfolioStore((s) => s.removeAlert);
  const toggleAlert = usePortfolioStore((s) => s.toggleAlert);

  const [tokenKey, setTokenKey] = useState("");
  const [type, setType] = useState<AlertRule["type"]>("prix_au_dessus");
  const [threshold, setThreshold] = useState("");

  function handleCreate() {
    const [chain, address] = tokenKey.split("|");
    const val = parseFloat(threshold);
    if (!chain || !address || Number.isNaN(val)) return;
    addAlert({ chain: chain as AlertRule["chain"], tokenAddress: address, type, threshold: val });
    setThreshold("");
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center gap-2">
        <Bell size={16} className="text-base-400" />
        <CardTitle>Alertes intelligentes</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-4">
          <select
            value={tokenKey}
            onChange={(e) => setTokenKey(e.target.value)}
            className="focus-ring rounded-lg border border-white/10 bg-white/[0.02] px-2 py-2 text-xs sm:col-span-2"
          >
            <option value="">Selectionner un token</option>
            {tokens.map((t) => (
              <option key={`${t.chain}:${t.address}`} value={`${t.chain}|${t.address}`}>
                {t.symbol} ({t.chain})
              </option>
            ))}
          </select>
          <select
            value={type}
            onChange={(e) => setType(e.target.value as AlertRule["type"])}
            className="focus-ring rounded-lg border border-white/10 bg-white/[0.02] px-2 py-2 text-xs"
          >
            {Object.entries(alertTypeLabels).map(([k, label]) => (
              <option key={k} value={k}>{label}</option>
            ))}
          </select>
          <div className="flex gap-2">
            <input
              value={threshold}
              onChange={(e) => setThreshold(e.target.value)}
              type="number"
              step="any"
              placeholder="Seuil"
              className="focus-ring mono-num w-full rounded-lg border border-white/10 bg-white/[0.02] px-2 py-2 text-xs"
            />
            <button onClick={handleCreate} className="focus-ring flex-shrink-0 rounded-lg bg-accent px-3 text-xs font-medium text-white hover:opacity-90">
              Creer
            </button>
          </div>
        </div>

        {alerts.length === 0 ? (
          <p className="py-4 text-center text-xs text-base-500">Aucune alerte configuree.</p>
        ) : (
          <ul className="space-y-1.5">
            {alerts.map((a) => {
              const token = tokens.find((t) => t.chain === a.chain && t.address === a.tokenAddress);
              return (
                <li
                  key={a.id}
                  className={clsx(
                    "flex items-center justify-between rounded-lg border px-3 py-2 text-xs",
                    a.triggeredAt ? "border-signal-amber/30 bg-signal-amberDim" : "border-white/10 bg-white/[0.02]"
                  )}
                >
                  <div className="flex items-center gap-2">
                    {a.triggeredAt ? <BellRing size={13} className="text-signal-amber" /> : <Bell size={13} className="text-base-500" />}
                    <span className="text-base-200">
                      {token?.symbol ?? "?"} — {alertTypeLabels[a.type]} {a.threshold}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => toggleAlert(a.id)} aria-label="Activer/desactiver">
                      {a.active ? <BellRing size={13} className="text-base-400" /> : <BellOff size={13} className="text-base-600" />}
                    </button>
                    <button onClick={() => removeAlert(a.id)} aria-label="Supprimer">
                      <Trash2 size={13} className="text-base-500 hover:text-signal-down" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
