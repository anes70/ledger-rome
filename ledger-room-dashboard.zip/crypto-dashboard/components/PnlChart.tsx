"use client";

import { AreaChart, Area, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { usePortfolioStore } from "@/store/usePortfolioStore";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/Card";
import { formatUsd } from "@/lib/utils";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export function PnlChart() {
  const snapshots = usePortfolioStore((s) => s.snapshots);

  const data = snapshots.map((s) => ({
    time: s.timestamp,
    value: s.totalValueUsd
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle>Evolution du portefeuille</CardTitle>
      </CardHeader>
      <CardContent>
        {data.length < 2 ? (
          <div className="flex h-[220px] flex-col items-center justify-center gap-1 text-center">
            <p className="text-sm text-base-400">L&rsquo;historique se construit a chaque actualisation.</p>
            <p className="text-xs text-base-500">Revenez apres quelques rafraichissements pour voir la courbe.</p>
          </div>
        ) : (
          <div className="h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="valueGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#5B8CFF" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#5B8CFF" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis
                  dataKey="time"
                  tickFormatter={(t) => format(t, "d MMM HH:mm", { locale: fr })}
                  stroke="rgba(255,255,255,0.2)"
                  tick={{ fontSize: 10, fill: "#6B7385" }}
                  minTickGap={40}
                />
                <YAxis
                  tickFormatter={(v) => formatUsd(v, { compact: true })}
                  stroke="rgba(255,255,255,0.2)"
                  tick={{ fontSize: 10, fill: "#6B7385" }}
                  width={60}
                />
                <Tooltip
                  labelFormatter={(t) => format(Number(t), "d MMM yyyy HH:mm", { locale: fr })}
                  formatter={(value: number) => [formatUsd(value), "Valeur"]}
                  contentStyle={{
                    background: "#10141B",
                    border: "1px solid rgba(255,255,255,0.08)",
                    borderRadius: 8,
                    fontSize: 12
                  }}
                />
                <Area type="monotone" dataKey="value" stroke="#5B8CFF" strokeWidth={2} fill="url(#valueGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
