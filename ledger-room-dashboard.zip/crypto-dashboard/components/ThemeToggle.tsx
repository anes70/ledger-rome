"use client";

import { Moon, Sun } from "lucide-react";
import { useSettingsStore } from "@/store/useSettingsStore";

export function ThemeToggle() {
  const mode = useSettingsStore((s) => s.mode);
  const toggleMode = useSettingsStore((s) => s.toggleMode);

  return (
    <button
      onClick={toggleMode}
      aria-label="Basculer entre mode clair et sombre"
      className="focus-ring flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-base-300 transition hover:text-base-100 hover:border-white/20"
    >
      {mode === "dark" ? <Sun size={16} /> : <Moon size={16} />}
    </button>
  );
}
