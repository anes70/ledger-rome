import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        base: {
          950: "#07090C",
          900: "#0B0E13",
          850: "#10141B",
          800: "#151A23",
          700: "#1D232E",
          600: "#2A3140",
          500: "#3D465A",
          400: "#6B7385",
          300: "#9AA1B0",
          200: "#C7CBD4",
          100: "#EDEFF3"
        },
        signal: {
          up: "#1FE0A6",
          upDim: "#0F3A30",
          down: "#FF5C72",
          downDim: "#3A1620",
          amber: "#FFB454",
          amberDim: "#3A2A10"
        },
        accent: {
          DEFAULT: "#5B8CFF",
          dim: "#16223F"
        }
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "SFMono-Regular", "monospace"]
      },
      boxShadow: {
        glass: "0 1px 0 0 rgba(255,255,255,0.04) inset, 0 8px 32px rgba(0,0,0,0.35)"
      },
      backgroundImage: {
        "grid-fade":
          "linear-gradient(to bottom, rgba(91,140,255,0.06), transparent 60%)"
      },
      keyframes: {
        pulse-dot: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.35" }
        },
        rise: {
          "0%": { transform: "translateY(6px)", opacity: "0" },
          "100%": { transform: "translateY(0)", opacity: "1" }
        }
      },
      animation: {
        "pulse-dot": "pulse-dot 1.8s ease-in-out infinite",
        rise: "rise 0.35s ease-out"
      }
    }
  },
  plugins: []
};

export default config;
